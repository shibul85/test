import React, { useState, useEffect } from 'react';
import { useAppLogic } from '@/hooks/useAppLogic';
import { useAuth } from '@/hooks/useAuth';
import { useInventory } from '@/hooks/useInventory';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import MainContent from '@/components/MainContent';
import { Toaster } from '@/components/ui/toaster';
import { Dialog, DialogOverlay } from '@/components/ui/dialog';
import PrescriptionScanner from '@/components/PrescriptionScanner';
import AuthModal from '@/components/AuthModal';
import AboutUsModal from '@/components/AboutUsModal';
import StoreDetailsModal from '@/components/StoreDetailsModal';
import InventoryModal from '@/components/InventoryModal';
import LocationPopup from '@/components/LocationPopup';
import HealthBlogModal from '@/components/HealthBlogModal';
import BillPreviewModal from '@/components/BillPreviewModal';
import { toast } from '@/components/ui/use-toast';

const AppLogo = "https://storage.googleapis.com/hostinger-horizons-assets-prod/9e7c0e90-d1ac-4b7d-957f-05928bb6595e/636587a4ca4ab1e68beb3c7021dbc5d4.png";

function App() {
  const { stores: inventoryStores, isLoading: inventoryIsLoading, updateStock } = useInventory();
  const appLogic = useAppLogic(inventoryStores, inventoryIsLoading);
  const {
    user,
    storeOwner,
    activeModal,
    setActiveModal,
    authMode,
    setAuthMode,
    openAuthModal,
    handleSignup,
    handleLogin,
    handleLogout,
    handleSocialLogin,
    handleStoreOwnerLogin,
    handleStoreOwnerSignup,
    handleStoreOwnerLogout,
  } = useAuth();
  
  const [selectedStore, setSelectedStore] = useState(null);
  const [activeMainTab, setActiveMainTab] = useState('search'); 
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [showLocationPopup, setShowLocationPopup] = useState(false);
  const [billDetails, setBillDetails] = useState(null);

  useEffect(() => {
    if (appLogic.selectedCity && appLogic.selectedCity.name === "Bargarh") {
      const popupShown = localStorage.getItem('bargarhPopupShown');
      if (!popupShown) {
        setShowLocationPopup(true);
        localStorage.setItem('bargarhPopupShown', 'true');
      }
    } else {
      setShowLocationPopup(false);
    }
  }, [appLogic.selectedCity]);

  const handlePrescriptionScan = (scannedText) => {
    appLogic.setSearchQuery(scannedText);
    setActiveMainTab('search');
    setIsScannerOpen(false);
    toast({
      title: "AI Scan Complete!",
      description: `Searching for: ${scannedText}`
    });
    setTimeout(() => appLogic.handleSearchMedicines(scannedText), 100);
  };

  const handleLogoClick = () => {
    window.location.href = '/';
  };

  const openInventory = () => {
    if (storeOwner) {
      setActiveModal('inventory');
    } else {
      setActiveModal('inventoryAuth');
    }
  };
  
  const handleInventoryAuthSuccess = () => {
    setActiveModal('inventory');
  }

  const handleShowBill = (details) => {
    setBillDetails(details);
    setActiveModal('billPreview');
  }

  const isAnyModalOpen = activeModal !== null || !!selectedStore || isScannerOpen || !!billDetails;

  return (
    <div className={`min-h-screen flex flex-col bg-gradient-to-br from-slate-100 via-sky-100 to-purple-100 dark:from-slate-900 dark:via-sky-900 dark:to-purple-900 text-slate-800 dark:text-slate-200 ${isAnyModalOpen ? 'app-container-blur' : ''}`}>
      <Toaster />
      <Header 
        logo={AppLogo} 
        appName="MyMedikare" 
        cities={appLogic.cities}
        selectedCity={appLogic.selectedCity || appLogic.cities[0]}
        onCityChange={appLogic.handleCityChange}
        user={user}
        onLogin={() => openAuthModal('login')}
        onSignup={() => openAuthModal('signup')}
        onLogout={handleLogout}
        onLogoClick={handleLogoClick}
      />

      <main className="flex-grow">
        <MainContent 
          logic={appLogic}
          activeTab={activeMainTab}
          onTabChange={setActiveMainTab}
          onSelectStore={setSelectedStore}
          onScanPrescriptionRequest={() => setIsScannerOpen(true)}
        />
      </main>

      <Footer 
        email="help@mymedikare.com" 
        phone="8144349805" 
        onAboutClick={() => setActiveModal('about')}
        onInventoryClick={openInventory}
        onHealthBlogClick={() => setActiveModal('healthBlog')}
      />
      
      {isScannerOpen && (
         <Dialog open={isScannerOpen} onOpenChange={setIsScannerOpen}>
          <DialogOverlay className="bg-black/60 backdrop-blur-sm" />
           <PrescriptionScanner
            onScanComplete={handlePrescriptionScan}
            onClose={() => setIsScannerOpen(false)}
          />
        </Dialog>
      )}

      <AuthModal 
        isOpen={activeModal === 'auth'}
        onOpenChange={() => setActiveModal(null)}
        mode={authMode}
        onModeChange={setAuthMode}
        onLogin={handleLogin}
        onSignup={handleSignup}
        onSocialLogin={handleSocialLogin}
        isStoreOwnerAuth={false}
      />
      
      <AuthModal 
        isOpen={activeModal === 'inventoryAuth'}
        onOpenChange={() => setActiveModal(null)}
        mode={authMode} 
        onModeChange={setAuthMode}
        onLogin={(creds) => handleStoreOwnerLogin(creds, handleInventoryAuthSuccess)}
        onSignup={(creds) => handleStoreOwnerSignup(creds, handleInventoryAuthSuccess)}
        onSocialLogin={(provider) => {
           toast({ title: `Log in with ${provider}`, description: "Store owner social login coming soon!", });
        }}
        isStoreOwnerAuth={true}
        title={authMode === 'login' ? "Store Owner Login" : "Store Owner Registration"}
        description={authMode === 'login' ? "Access your store's inventory and billing." : "Register to manage your store."}
      />

      <AboutUsModal
        isOpen={activeModal === 'about'}
        onOpenChange={() => setActiveModal(null)}
      />
      
      <HealthBlogModal
        isOpen={activeModal === 'healthBlog'}
        onOpenChange={() => setActiveModal(null)}
      />
      
      {storeOwner && (
        <InventoryModal
          isOpen={activeModal === 'inventory'}
          onOpenChange={() => setActiveModal(null)}
          stores={inventoryStores}
          updateStock={updateStock}
          onLogout={handleStoreOwnerLogout}
          onShowBill={handleShowBill}
        />
      )}

      <BillPreviewModal
        isOpen={activeModal === 'billPreview'}
        onOpenChange={() => setActiveModal(null)}
        billDetails={billDetails}
      />

      <StoreDetailsModal
        store={selectedStore}
        onOpenChange={() => setSelectedStore(null)}
        userLocation={appLogic.userLocation || appLogic.defaultOdishaLocation}
      />
      <LocationPopup
        isOpen={showLocationPopup}
        onClose={() => setShowLocationPopup(false)}
        cityName="Bargarh"
      />
    </div>
  );
}

export default App;