import { medicinesPart1 } from './medicines/part1';
import { medicinesPart2 } from './medicines/part2';
import { medicinesPart3 } from './medicines/part3';
import { medicinesPart4 } from './medicines/part4';
import { medicinesPart5 } from './medicines/part5';
import { medicinesPart6 } from './medicines/part6';
import { medicinesPart7 } from './medicines/part7';
import { medicinesPart8 } from './medicines/part8';
import { medicinesPart9 } from './medicines/part9';
import { medicinesPart10 } from './medicines/part10';
import { medicineInfo } from './medicineInfo';


const combinedMedicines = [
  ...new Set([
    ...medicinesPart1,
    ...medicinesPart2,
    ...medicinesPart3,
    ...medicinesPart4,
    ...medicinesPart5,
    ...medicinesPart6,
    ...medicinesPart7,
    ...medicinesPart8,
    ...medicinesPart9,
    ...medicinesPart10
  ])
];

export const allMedicinesData = combinedMedicines.map(medName => ({
  name: medName,
  description: medicineInfo[medName]?.description || "General purpose medicine."
}));

export const allMedicines = combinedMedicines;


export const diseaseToMedicineMap = {
  "Fever": ["Paracetamol", "Ibuprofen", "Dolo 650", "Crocin Advance", "Calpol 500mg", "Meftal Spas"],
  "Cold": ["Cetirizine", "Loratadine", "Sinarest", "Vicks Action 500", "Alex Syrup", "Solvin Cold Syrup"],
  "Cough": ["Benadryl Syrup", "Ascoril LS Syrup", "Grilinctus Syrup", "Corex DX Syrup", "Honitus Syrup", "Koflet Syrup"],
  "Headache": ["Aspirin", "Saridon", "Combiflam", "Naproxen"],
  "Body Pain": ["Ibuprofen", "Combiflam", "Moov Pain Relief", "Volini Gel", "Diclofenac"],
  "Acidity": ["Omeprazole", "Ranitidine", "Pantoprazole", "Eno Fruit Salt", "Digene Gel", "Gelusil MPS"],
  "Diarrhea": ["Loperamide", "Eldoper Capsule", "ORS Powder", "Enterogermina Oral Suspension", "Racecadotril"],
  "Constipation": ["Isabgol Husk", "Dulcolax", "Cremaffin", "Lactulose"],
  "Allergy": ["Cetirizine", "Loratadine", "Allegra 120mg", "Avil 25mg", "Montelukast"],
  "Diabetes": ["Metformin", "Glycomet GP 2 Tablet", "Janumet 50/500 Tablet", "Insulin", "Glimestar M2"],
  "Hypertension": ["Amlodipine", "Lisinopril", "Telma 40 Tablet", "Losar H Tablet", "Metoprolol"],
  "Asthma": ["Salbutamol", "Montelukast", "Budecort Respules", "Seroflo Inhaler", "Foracort Inhaler"],
  "Skin Infection": ["Clotrimazole Cream", "Miconazole Cream", "Soframycin Skin Cream", "Nadibact Cream", "Fluconazole"],
  "Eye Infection": ["Ciplox Eye Drops", "Moxifloxacin Eye Drops", "Tobramycin Eye Drops"],
  "Vitamin Deficiency": ["Revital H", "Supradyn Tablets", "Neurobion Forte", "Becosules Z Capsule", "Shelcal 500mg"],
  "Anemia": ["Orofer XT Tablet", "Tonoferon Syrup", "Dexorange Capsule", "Fefol Z Capsule", "Ferinject Injection"],
  "Pain and Inflammation": ["Diclofenac", "Aceclofenac", "Etoricoxib Tablet", "Nise Gel", "Flexon MR Tablet"],
  "Gastric Ulcer": ["Pantoprazole", "Omeprazole", "Sucralfate Suspension", "Rantac 150 Tablet"],
  "Nausea and Vomiting": ["Ondansetron", "Domperidone", "Metoclopramide", "Doxinate Tablet"],
  "Fungal Infection": ["Fluconazole", "Ketoconazole Shampoo", "Candid B Cream", "Terbinafine Cream"],
  "Bacterial Infection": ["Amoxicillin", "Azithromycin", "Ciprofloxacin", "Augmentin Duo Syrup", "Zifi 200 Tablet"],
  "Joint Pain": ["Glucosamine", "Chondroitin", "Collagen Peptides", "Dynapar QPS"],
  "Insomnia": ["Zolpidem", "Melatonin", "Alprazolam (short-term)"],
  "Anxiety": ["Alprazolam", "Lorazepam", "Sertraline", "Escitalopram", "Buspirone"],
  "Depression": ["Fluoxetine", "Sertraline", "Escitalopram", "Amitriptyline", "Mirtazapine"],
  "Thyroid Disorder": ["Levothyroxine", "Thyronorm 75mcg Tablet", "Eltroxin 50mcg Tablet", "Methimazole"],
  "High Cholesterol": ["Atorvastatin", "Simvastatin", "Rosuvas 10 Tablet", "Fenofibrate"],
  "Migraine": ["Sumatriptan", "Naproxen", "Propranolol (prophylaxis)", "Topiramate (prophylaxis)"],
  "Vertigo": ["Betahistine", "Cinnarizine", "Prochlorperazine", "Dimenhydrinate"],
  "Epilepsy": ["Valproic Acid Syrup", "Levetiracetam Tablet", "Phenytoin Tablet", "Carbamazepine Tablet"],
  "Malaria": ["Chloroquine", "Artemether/Lumefantrine", "Mefloquine"],
  "Dengue": ["Paracetamol (for fever)", "ORS Powder (for hydration)"],
  "Chikungunya": ["Paracetamol", "Ibuprofen (for pain)"],
  "Tuberculosis": ["Rifampin", "Isoniazid", "Pyrazinamide", "Ethambutol"],
  "Urinary Tract Infection (UTI)": ["Norfloxacin", "Ciprofloxacin", "Nitrofurantoin", "Urispas Tablet"],
  "Common Cold": ["Paracetamol", "Cetirizine", "Phenylephrine (decongestant)"],
  "Sore Throat": ["Strepsils", "Cofsils Lozenges", "Betadine Gargle"],
  "Motion Sickness": ["Dimenhydrinate", "Promethazine", "Avomine Tablet"],
  "Menstrual Pain": ["Meftal Spas", "Ibuprofen", "Naproxen", "Drotin DS Tablet"],
  "Indigestion": ["Pudin Hara", "Hajmola", "Unienzyme Tablet", "Festal N Tablet"]
};