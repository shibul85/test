export const odishaStores = [
  {
    id: 1,
    name: "Odisha Medical Hall",
    address: "Modipara, Sambalpur, Odisha 768001",
    distance: 1.5,
    rating: 4.6,
    phone: "+919437050123",
    openHours: "8:00 AM - 10:00 PM",
    coordinates: [21.4669, 83.9812] 
  },
  {
    id: 2,
    name: "Capital Pharmacy",
    address: "Sahid Nagar, Bhubaneswar, Odisha 751007",
    distance: 0.5,
    rating: 4.8,
    phone: "+916742540123",
    openHours: "9:00 AM - 11:00 PM",
    coordinates: [20.2961, 85.8245] 
  },
  {
    id: 3,
    name: "Bargarh Drug House",
    address: "Near Bus Stand, Bargarh, Odisha 768028",
    distance: 1.0,
    rating: 4.4,
    phone: "+919937012345",
    openHours: "10:00 AM - 9:00 PM",
    coordinates: [21.3374, 83.6219] 
  },
  {
    id: 4,
    name: "Maa Samaleswari Medicals",
    address: "Ainthapali, Sambalpur, Odisha 768004",
    distance: 2.1,
    rating: 4.5,
    phone: "+919861098765",
    openHours: "8:30 AM - 10:30 PM",
    coordinates: [21.4915, 83.9907]
  },
  {
    id: 5,
    name: "Jan Aushadhi Kendra - Bhubaneswar",
    address: "Master Canteen Area, Bhubaneswar, Odisha 751001",
    distance: 0.3,
    rating: 4.9,
    phone: "+916742530987",
    openHours: "9:00 AM - 9:00 PM",
    coordinates: [20.2750, 85.8410]
  },
  {
    id: 6,
    name: "Apollo Pharmacy - Sambalpur",
    address: "VV Road, Sambalpur, Odisha 768001",
    distance: 0.8,
    rating: 4.7,
    phone: "+919087654321",
    openHours: "24/7",
    coordinates: [21.4700, 83.9750]
  },
  {
    id: 7,
    name: "MedPlus - Bhubaneswar IRC Village",
    address: "IRC Village, Nayapalli, Bhubaneswar, Odisha 751015",
    distance: 1.2,
    rating: 4.5,
    phone: "+917890123456",
    openHours: "8:00 AM - 11:00 PM",
    coordinates: [20.2910, 85.8180]
  },
  {
    id: 8,
    name: "Wellness Forever - Bargarh Town",
    address: "Main Road, Bargarh Town, Bargarh, Odisha 768028",
    distance: 0.4,
    rating: 4.6,
    phone: "+918765432109",
    openHours: "7:00 AM - 12:00 AM",
    coordinates: [21.3390, 83.6250]
  },
   {
    id: 9,
    name: "City Medical Store",
    address: "Budharaja, Sambalpur, Odisha 768004",
    distance: 1.1,
    rating: 4.3,
    phone: "+919112233445",
    openHours: "9:00 AM - 9:30 PM",
    coordinates: [21.4850, 83.9800]
  },
  {
    id: 10,
    name: "Pradhan Medicals",
    address: "Old Town, Bhubaneswar, Odisha 751002",
    distance: 2.5,
    rating: 4.2,
    phone: "+919223344556",
    openHours: "10:00 AM - 8:00 PM",
    coordinates: [20.2430, 85.8310]
  },
  {
    id: 11,
    name: "Seva Pharmacy",
    address: "George High School Road, Bargarh, Odisha 768028",
    distance: 0.7,
    rating: 4.7,
    phone: "+919334455667",
    openHours: "8:00 AM - 10:00 PM",
    coordinates: [21.3320, 83.6180]
  },
  {
    id: 12,
    name: "Cuttack Medico",
    address: "Badambadi, Cuttack, Odisha 753009",
    distance: 1.8,
    rating: 4.5,
    phone: "+919445566778",
    openHours: "24/7",
    coordinates: [20.4704, 85.8756]
  },
  {
    id: 13,
    name: "Rourkela Health Corner",
    address: "Sector 19, Rourkela, Odisha 769008",
    distance: 3.2,
    rating: 4.6,
    phone: "+919556677889",
    openHours: "9:00 AM - 11:00 PM",
    coordinates: [22.2574, 84.8888]
  },
  {
    id: 14,
    name: "Puri Beach Pharmacy",
    address: "Sea Beach Road, Puri, Odisha 752001",
    distance: 0.2,
    rating: 4.8,
    phone: "+919667788990",
    openHours: "8:00 AM - 10:00 PM",
    coordinates: [19.8052, 85.8275]
  },
  {
    id: 15,
    name: "Life Savers Drug House",
    address: "Patia, Bhubaneswar, Odisha 751024",
    distance: 4.5,
    rating: 4.7,
    phone: "+919778899001",
    openHours: "8:00 AM - 11:30 PM",
    coordinates: [20.3544, 85.8153]
  },
  {
    id: 16,
    name: "Sai Krupa Medical Store",
    address: "Link Road, Cuttack, Odisha 753012",
    distance: 2.2,
    rating: 4.4,
    phone: "+919889900112",
    openHours: "9:00 AM - 10:00 PM",
    coordinates: [20.4811, 85.8619]
  },
  {
    id: 17,
    name: "Balaji Medicals",
    address: "Civil Township, Rourkela, Odisha 769004",
    distance: 1.5,
    rating: 4.3,
    phone: "+919990011223",
    openHours: "8:30 AM - 9:30 PM",
    coordinates: [22.2485, 84.8350]
  },
  {
    id: 18,
    name: "Grand Road Pharmacy",
    address: "Bada Danda, Puri, Odisha 752001",
    distance: 0.8,
    rating: 4.6,
    phone: "+919001122334",
    openHours: "7:00 AM - 11:00 PM",
    coordinates: [19.8099, 85.8295]
  },
  {
    id: 19,
    name: "Care Pharmacy Sambalpur",
    address: "Dhanupali, Sambalpur, Odisha 768005",
    distance: 3.0,
    rating: 4.5,
    phone: "+918112233445",
    openHours: "10:00 AM - 10:00 PM",
    coordinates: [21.4500, 83.9500]
  },
  {
    id: 20,
    name: "Modern Medical Store",
    address: "Chandrasekharpur, Bhubaneswar, Odisha 751016",
    distance: 3.5,
    rating: 4.7,
    phone: "+917223344556",
    openHours: "9:00 AM - 11:00 PM",
    coordinates: [20.3330, 85.8330]
  },
  {
    id: 21,
    name: "Bolangir Central Pharmacy",
    address: "Palace Line, Bolangir, Odisha 767001",
    distance: 0.5,
    rating: 4.5,
    phone: "+919876500001",
    openHours: "9:00 AM - 10:00 PM",
    coordinates: [20.7143, 83.4866]
  },
  {
    id: 22,
    name: "Sonepur Medical Emporium",
    address: "Main Road, Sonepur, Odisha 767017",
    distance: 0.3,
    rating: 4.3,
    phone: "+919876500002",
    openHours: "10:00 AM - 9:00 PM",
    coordinates: [20.8491, 83.9090]
  },
  {
    id: 23,
    name: "Nayagarh Health Hub",
    address: "College Road, Nayagarh, Odisha 752069",
    distance: 1.2,
    rating: 4.6,
    phone: "+919876500003",
    openHours: "8:30 AM - 10:30 PM",
    coordinates: [20.1299, 85.0980]
  },
  {
    id: 24,
    name: "Burla Medical Point",
    address: "VSS Marg, Burla, Sambalpur, Odisha 768017",
    distance: 0.8,
    rating: 4.7,
    phone: "+919876500004",
    openHours: "24/7",
    coordinates: [21.5070, 83.8700]
  },
  {
    id: 25,
    name: "Jagdalpur City Medicos",
    address: "Chitrakote Road, Jagdalpur, Chhattisgarh 494001",
    distance: 2.1,
    rating: 4.4,
    phone: "+919876500005",
    openHours: "9:00 AM - 11:00 PM",
    coordinates: [19.0700, 82.0300]
  },
  {
    id: 26,
    name: "Rayagada Pharmacy",
    address: "New Colony, Rayagada, Odisha 765001",
    distance: 1.0,
    rating: 4.5,
    phone: "+919876500006",
    openHours: "8:00 AM - 10:00 PM",
    coordinates: [19.1700, 83.4200]
  }
];

export const initialMockStores = odishaStores;