import { useState, useEffect } from 'react';
import { toast } from '@/components/ui/use-toast';

export const useAuth = () => {
  const [user, setUser] = useState(null);
  const [storeOwner, setStoreOwner] = useState(null);
  const [activeModal, setActiveModal] = useState(null);
  const [authMode, setAuthMode] = useState('login');

  useEffect(() => {
    const loggedInUser = localStorage.getItem('myMedikareUser');
    if (loggedInUser) {
      setUser(JSON.parse(loggedInUser));
    }
    const loggedInStoreOwner = localStorage.getItem('myMedikareStoreOwner');
    if (loggedInStoreOwner) {
      setStoreOwner(JSON.parse(loggedInStoreOwner));
    }
  }, []);

  const openAuthModal = (mode) => {
    setAuthMode(mode);
    setActiveModal('auth');
  };

  const handleSignup = ({ name, email, password }) => {
    let users = JSON.parse(localStorage.getItem('myMedikareUsers')) || [];
    if (users.find(u => u.email === email)) {
      toast({ title: "Signup Failed", description: "An account with this email already exists.", variant: "destructive" });
      return;
    }
    const newUser = { id: Date.now(), name, email, password };
    users.push(newUser);
    localStorage.setItem('myMedikareUsers', JSON.stringify(users));
    localStorage.setItem('myMedikareUser', JSON.stringify(newUser));
    setUser(newUser);
    setActiveModal(null);
    toast({ title: "Welcome!", description: "Your account has been created successfully." });
  };

  const handleLogin = ({ email, password }) => {
    let users = JSON.parse(localStorage.getItem('myMedikareUsers')) || [];
    const foundUser = users.find(u => u.email === email && u.password === password);
    if (foundUser) {
      localStorage.setItem('myMedikareUser', JSON.stringify(foundUser));
      setUser(foundUser);
      setActiveModal(null);
      toast({ title: "Login Successful", description: "Welcome back!" });
    } else {
      toast({ title: "Login Failed", description: "Invalid email or password.", variant: "destructive" });
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('myMedikareUser');
    setUser(null);
    toast({ title: "Logged Out", description: "You have been successfully logged out." });
  };
  
  const handleSocialLogin = (provider) => {
      toast({
          title: `Log in with ${provider}`,
          description: "This feature isn't implemented yet. Please complete Supabase integration to enable social logins! 🚀",
      });
  };

  const handleStoreOwnerSignup = ({ name, email, password }, callback) => {
    let owners = JSON.parse(localStorage.getItem('myMedikareStoreOwners')) || [];
    if (owners.find(o => o.email === email)) {
      toast({ title: "Registration Failed", description: "A store owner account with this email already exists.", variant: "destructive" });
      return;
    }
    const newOwner = { id: Date.now(), name, email, password };
    owners.push(newOwner);
    localStorage.setItem('myMedikareStoreOwners', JSON.stringify(owners));
    localStorage.setItem('myMedikareStoreOwner', JSON.stringify(newOwner));
    setStoreOwner(newOwner);
    setActiveModal(null);
    toast({ title: "Store Owner Registered!", description: "You can now access inventory management." });
    if (callback) callback();
  };

  const handleStoreOwnerLogin = ({ email, password }, callback) => {
    let owners = JSON.parse(localStorage.getItem('myMedikareStoreOwners')) || [];
    const foundOwner = owners.find(o => o.email === email && o.password === password);
    if (foundOwner) {
      localStorage.setItem('myMedikareStoreOwner', JSON.stringify(foundOwner));
      setStoreOwner(foundOwner);
      setActiveModal(null);
      toast({ title: "Store Owner Login Successful", description: "Welcome back!" });
      if (callback) callback();
    } else {
      toast({ title: "Store Owner Login Failed", description: "Invalid email or password.", variant: "destructive" });
    }
  };

  const handleStoreOwnerLogout = () => {
    localStorage.removeItem('myMedikareStoreOwner');
    setStoreOwner(null);
    setActiveModal(null);
    toast({ title: "Store Owner Logged Out", description: "You have been successfully logged out from the inventory system." });
  };


  return {
    user,
    storeOwner,
    activeModal,
    setActiveModal,
    authMode,
    setAuthMode,
    openAuthModal,
    handleSignup,
    handleLogin,
    handleLogout,
    handleSocialLogin,
    handleStoreOwnerSignup,
    handleStoreOwnerLogin,
    handleStoreOwnerLogout,
  };
};