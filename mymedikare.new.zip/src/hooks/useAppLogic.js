import { useState, useEffect, useCallback } from 'react';
import { toast } from '@/components/ui/use-toast';
import { allMedicinesData, diseaseToMedicineMap } from '@/data/medicinesData'; 
import { medicineInfo } from '@/data/medicineInfo';
import { getUserLocation, calculateDistanceToStore } from '@/lib/locationUtils';

const defaultOdishaLocation = { lat: 20.9517, lng: 85.0985 };

const cities = [
  { name: "All Odisha", coordinates: defaultOdishaLocation, zoom: 7 },
  { name: "Sambalpur", coordinates: { lat: 21.4669, lng: 83.9812 }, zoom: 12 },
  { name: "Bhubaneswar", coordinates: { lat: 20.2961, lng: 85.8245 }, zoom: 12 },
  { name: "Bargarh", coordinates: { lat: 21.3374, lng: 83.6219 }, zoom: 12 },
  { name: "Cuttack", coordinates: { lat: 20.4625, lng: 85.8830 }, zoom: 12 },
  { name: "Rourkela", coordinates: { lat: 22.2604, lng: 84.8536 }, zoom: 12 },
  { name: "Puri", coordinates: { lat: 19.8135, lng: 85.8312 }, zoom: 13 },
  { name: "Bolangir", coordinates: { lat: 20.7143, lng: 83.4866 }, zoom: 12 },
  { name: "Sonepur", coordinates: { lat: 20.8491, lng: 83.9090 }, zoom: 12 },
  { name: "Nayagarh", coordinates: { lat: 20.1299, lng: 85.0980 }, zoom: 12 },
  { name: "Burla", coordinates: { lat: 21.5070, lng: 83.8700 }, zoom: 13 },
  { name: "Jagdalpur", coordinates: { lat: 19.0700, lng: 82.0300 }, zoom: 12 },
  { name: "Rayagada", coordinates: { lat: 19.1700, lng: 83.4200 }, zoom: 12 },
];

const allDiseaseNames = Object.keys(diseaseToMedicineMap);
const allCompositionNames = [...new Set(Object.values(medicineInfo).map(info => info.composition).filter(Boolean))];


export const useAppLogic = (inventoryStores, inventoryIsLoading) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [userLocation, setUserLocation] = useState(null);
  const [filteredStores, setFilteredStores] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [diseaseSuggestions, setDiseaseSuggestions] = useState([]);
  const [showDiseaseSuggestions, setShowDiseaseSuggestions] = useState(false);
  const [selectedCity, setSelectedCity] = useState(cities[0]);
  const [searchType, setSearchType] = useState('medicine'); 

  useEffect(() => {
    getUserLocation(
      (location) => setUserLocation(location),
      (error) => {
        console.error('Error getting location:', error);
        setUserLocation(defaultOdishaLocation);
      }
    );
  }, []);
  
  const updateDisplayedStores = useCallback((storesToSort = inventoryStores) => {
    if (!inventoryIsLoading) {
      let storesToDisplay = storesToSort;
      if (selectedCity && selectedCity.name !== "All Odisha") {
        storesToDisplay = storesToSort.filter(store => store.address.toLowerCase().includes(selectedCity.name.toLowerCase()));
      }
      
      if (userLocation) {
        storesToDisplay.sort((a, b) => {
          const distA = calculateDistanceToStore(a, userLocation);
          const distB = calculateDistanceToStore(b, userLocation);
          return distA - distB;
        });
      }
      setFilteredStores(storesToDisplay);
    }
  }, [inventoryStores, selectedCity, inventoryIsLoading, userLocation]);
  
  useEffect(() => {
    updateDisplayedStores();
  }, [inventoryStores, selectedCity, updateDisplayedStores, userLocation]);

  const handleCityChange = (city) => {
    setSelectedCity(city);
    setSearchQuery('');
    setSuggestions([]);
    setShowSuggestions(false);
    setDiseaseSuggestions([]);
    setShowDiseaseSuggestions(false);
  };

  const handleSearchTypeChange = (type) => {
    setSearchType(type);
    setSearchQuery('');
    setSuggestions([]);
    setShowSuggestions(false);
    setDiseaseSuggestions([]);
    setShowDiseaseSuggestions(false);
  };

  const handleSearchInputChange = (query) => {
    setSearchQuery(query);
    if (query.length > 1) {
      if (searchType === 'medicine') {
        const filteredSuggestions = allMedicinesData
          .filter(med => med.name.toLowerCase().includes(query.toLowerCase()))
          .slice(0, 10);
        setSuggestions(filteredSuggestions);
        setShowSuggestions(true);
        setShowDiseaseSuggestions(false);
      } else if (searchType === 'disease') {
        const filteredSuggestions = allDiseaseNames
          .filter(disease => disease.toLowerCase().includes(query.toLowerCase()))
          .slice(0, 10);
        setDiseaseSuggestions(filteredSuggestions);
        setShowDiseaseSuggestions(true);
        setShowSuggestions(false);
      } else if (searchType === 'composition') {
        const filteredSuggestions = allCompositionNames
          .filter(comp => comp.toLowerCase().includes(query.toLowerCase()))
          .map(compName => ({ name: compName, description: `Medicines containing ${compName}` })) 
          .slice(0, 10);
        setSuggestions(filteredSuggestions);
        setShowSuggestions(true);
        setShowDiseaseSuggestions(false);
      }
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
      setDiseaseSuggestions([]);
      setShowDiseaseSuggestions(false);
    }
  };

  const handleSearchMedicines = (query = searchQuery) => {
    if (!query.trim()) {
      toast({
        title: `Enter ${searchType} Name`,
        description: `Please enter a ${searchType} name to search.`,
        variant: "destructive"
      });
      return;
    }
    setShowSuggestions(false);
    setShowDiseaseSuggestions(false);
    setIsSearching(true);

    setTimeout(() => {
      const lowerCaseQuery = query.toLowerCase();
      let medicinesToSearchForNames = [];

      if (searchType === 'medicine') {
        medicinesToSearchForNames = [lowerCaseQuery];
      } else if (searchType === 'disease') {
        medicinesToSearchForNames = (diseaseToMedicineMap[query] || []).map(m => m.toLowerCase());
        if (medicinesToSearchForNames.length === 0) {
           const relatedDiseases = Object.keys(diseaseToMedicineMap).filter(d => d.toLowerCase().includes(lowerCaseQuery));
           relatedDiseases.forEach(rd => {
             medicinesToSearchForNames.push(...(diseaseToMedicineMap[rd] || []).map(m => m.toLowerCase()));
           });
           medicinesToSearchForNames = [...new Set(medicinesToSearchForNames)]; 
        }
      } else if (searchType === 'composition') {
         medicinesToSearchForNames = Object.entries(medicineInfo)
          .filter(([medName, info]) => info.composition && info.composition.toLowerCase().includes(lowerCaseQuery))
          .map(([medName]) => medName.toLowerCase());
      }
      
      if (medicinesToSearchForNames.length === 0 && (searchType === 'disease' || searchType === 'composition')) {
        setFilteredStores([]);
        setIsSearching(false);
        toast({
          title: `No Medicines Found for ${searchType}`,
          description: `No specific medicines are listed for "${query}" in our database. Try a broader term or different search type.`,
        });
        return;
      }

      let baseStoresForCity = inventoryStores;
      if (selectedCity && selectedCity.name !== "All Odisha") {
        baseStoresForCity = inventoryStores.filter(store => store.address.toLowerCase().includes(selectedCity.name.toLowerCase()));
      }
      
      const storesWithMedicine = baseStoresForCity.map(store => {
        let foundMedicine = null;
        for (const medToSearch of medicinesToSearchForNames) {
            const matchingMedicineName = Object.keys(store.medicines).find(medicineInStore =>
                medicineInStore.toLowerCase().includes(medToSearch)
            );
            if (matchingMedicineName && store.medicines[matchingMedicineName].stock > 0) {
                foundMedicine = {
                    name: matchingMedicineName,
                    ...store.medicines[matchingMedicineName]
                };
                break; 
            }
        }

        if (foundMedicine) {
            return {
                ...store,
                searchedMedicine: foundMedicine,
                distance: userLocation ? calculateDistanceToStore(store, userLocation) : calculateDistanceToStore(store, defaultOdishaLocation)
            };
        }
        return null;
      }).filter(store => store !== null);
      
      if (userLocation) {
        storesWithMedicine.sort((a, b) => a.distance - b.distance);
      }

      setFilteredStores(storesWithMedicine);
      setIsSearching(false);

      if (storesWithMedicine.length === 0) {
        toast({
          title: "No Results Found",
          description: `No stores currently have ${searchType === 'medicine' ? `"${query}"` : searchType === 'disease' ? `medicines for "${query}"` : `medicines with composition "${query}"`} in stock in ${selectedCity.name}.`,
        });
      } else {
        toast({
          title: "Search Complete!",
          description: `Found ${storesWithMedicine.length} stores.`
        });
      }
    }, 1000);
  };
  
  const handleSuggestionClick = (suggestionName) => {
    setSearchQuery(suggestionName);
    setSuggestions([]);
    setShowSuggestions(false);
    handleSearchMedicines(suggestionName);
  };
  
  const handleDiseaseSuggestionClick = (diseaseName) => {
    setSearchQuery(diseaseName);
    setDiseaseSuggestions([]);
    setShowDiseaseSuggestions(false);
    handleSearchMedicines(diseaseName);
  };


  const clearSearch = () => {
    setSearchQuery('');
    setSuggestions([]);
    setShowSuggestions(false);
    setDiseaseSuggestions([]);
    setShowDiseaseSuggestions(false);
    updateDisplayedStores();
  };
  
  const isLoading = inventoryIsLoading || isSearching;

  return {
    searchQuery,
    userLocation,
    stores: filteredStores,
    isLoading,
    suggestions,
    showSuggestions,
    diseaseSuggestions,
    showDiseaseSuggestions,
    selectedCity,
    cities,
    defaultOdishaLocation,
    searchType,
    handleCityChange,
    handleSearchInputChange,
    handleSuggestionClick,
    handleDiseaseSuggestionClick,
    handleSearchMedicines,
    clearSearch,
    setSearchQuery,
    setShowSuggestions,
    setShowDiseaseSuggestions,
    handleSearchTypeChange,
  };
};