import { useState, useEffect, useCallback } from 'react';
import { odishaStores } from '@/data/storeData';
import { allMedicinesData } from '@/data/medicinesData'; 

const initializeInventory = () => {
  console.log("Initializing inventory for the first time...");
  const storesWithInventory = odishaStores.map(store => {
    const medicines = {};
    const numMedicinesInStore = Math.floor(Math.random() * (700 - 300 + 1)) + 300;
    const shuffledAllMedicines = [...allMedicinesData].sort(() => 0.5 - Math.random());

    for (let i = 0; i < numMedicinesInStore && i < shuffledAllMedicines.length; i++) {
      const med = shuffledAllMedicines[i];
      medicines[med.name] = {
        stock: Math.floor(Math.random() * 200) + 20,
        price: (Math.random() * 450 + 50).toFixed(2),
        batch: `B${Math.floor(Math.random()*9000)+1000}`,
        exp: `${Math.floor(Math.random()*12)+1}/${new Date().getFullYear() + Math.floor(Math.random()*3)+1}`
      };
    }
    return { ...store, medicines };
  });
  localStorage.setItem('myMedikareInventory', JSON.stringify(storesWithInventory));
  return storesWithInventory;
};

export const useInventory = () => {
  const [stores, setStores] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    try {
      const savedInventory = localStorage.getItem('myMedikareInventory');
      if (savedInventory) {
        setStores(JSON.parse(savedInventory));
      } else {
        setStores(initializeInventory());
      }
    } catch (error) {
      console.error("Failed to parse inventory from localStorage, re-initializing.", error);
      setStores(initializeInventory());
    } finally {
      setIsLoading(false);
    }
  }, []);
  
  const updateInventory = useCallback((updatedStores) => {
    setStores(updatedStores);
    localStorage.setItem('myMedikareInventory', JSON.stringify(updatedStores));
  }, []);

  const updateStock = useCallback((storeId, medicineName, quantityChange, newPrice, newBatch, newExp) => {
    const updatedStores = stores.map(store => {
      if (store.id === storeId) {
        const newMedicines = { ...store.medicines };
        if (newMedicines[medicineName]) {
          newMedicines[medicineName].stock += quantityChange;
          if (newMedicines[medicineName].stock < 0) newMedicines[medicineName].stock = 0;
          if (newPrice !== undefined && quantityChange > 0) { // Update price only on stock-in
            newMedicines[medicineName].price = newPrice;
          }
           if (newBatch && quantityChange > 0) newMedicines[medicineName].batch = newBatch;
           if (newExp && quantityChange > 0) newMedicines[medicineName].exp = newExp;

        } else if (quantityChange > 0) { // Adding new medicine
          newMedicines[medicineName] = {
            stock: quantityChange,
            price: newPrice !== undefined ? newPrice : (Math.random() * 450 + 50).toFixed(2),
            batch: newBatch || `B${Math.floor(Math.random()*9000)+1000}`,
            exp: newExp || `${Math.floor(Math.random()*12)+1}/${new Date().getFullYear() + Math.floor(Math.random()*3)+1}`
          };
        }
        return { ...store, medicines: newMedicines };
      }
      return store;
    });
    updateInventory(updatedStores);
  }, [stores, updateInventory]);

  return { stores, isLoading, updateStock };
};