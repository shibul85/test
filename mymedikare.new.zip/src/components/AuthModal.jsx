import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LogIn, UserPlus, Phone, Building } from 'lucide-react';
import GoogleIcon from '@/components/icons/GoogleIcon';
import AppleIcon from '@/components/icons/AppleIcon';
import { toast } from '@/components/ui/use-toast';

const AuthModal = ({ 
  isOpen, 
  onOpenChange, 
  mode, 
  onModeChange, 
  onLogin, 
  onSignup, 
  onSocialLogin,
  isStoreOwnerAuth = false,
  title,
  description
}) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phoneNum, setPhoneNum] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [currentView, setCurrentView] = useState('main'); 

  const defaultTitle = isStoreOwnerAuth 
    ? (mode === 'login' ? "Store Owner Login" : "Store Owner Registration")
    : (mode === 'login' ? "Welcome Back!" : "Create Account");
  
  const defaultDescription = isStoreOwnerAuth
    ? (mode === 'login' ? "Access your store's inventory and billing." : "Register to manage your store.")
    : (mode === 'login' ? "Log in to access your account." : "Join MyMedikare for a better experience.");


  const handleLoginSubmit = (e) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      onLogin({ email, password });
      setIsLoading(false);
    }, 500);
  };

  const handleSignupSubmit = (e) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      onSignup({ name, email, password });
      setIsLoading(false);
    }, 500);
  };

  const handlePhoneSubmit = (e) => {
    e.preventDefault();
    toast({
        title: "Log in with Phone",
        description: "This feature isn't implemented yet. Please complete Supabase integration to enable phone authentication! 🚀",
    });
  }
  
  const resetForm = () => {
    setName('');
    setEmail('');
    setPassword('');
    setPhoneNum('');
  }

  const handleOpenChangeWithReset = (openState) => {
    if (!openState) {
      resetForm();
      setCurrentView('main');
    }
    onOpenChange(openState);
  }


  const renderMainContent = () => (
    <Tabs value={mode} onValueChange={onModeChange} className="w-full">
      <DialogHeader className="p-6 pb-0">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="login">
            {isStoreOwnerAuth ? <Building className="h-4 w-4 mr-2" /> : <LogIn className="h-4 w-4 mr-2" /> } Login
          </TabsTrigger>
          <TabsTrigger value="signup">
            {isStoreOwnerAuth ? <Building className="h-4 w-4 mr-2" /> : <UserPlus className="h-4 w-4 mr-2" /> } Sign Up
          </TabsTrigger>
        </TabsList>
      </DialogHeader>

      <AnimatePresence mode="wait">
        <motion.div
          key={mode}
          initial={{ opacity: 0, x: mode === 'login' ? 20 : -20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: mode === 'login' ? -20 : 20 }}
          transition={{ duration: 0.2 }}
          className="p-6"
        >
          {mode === 'login' ? (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <DialogTitle className="text-2xl font-bold text-center mb-1 text-slate-800 dark:text-slate-100">{title || defaultTitle}</DialogTitle>
              <DialogDescription className="text-center mb-4 text-slate-600 dark:text-slate-400">{description || defaultDescription}</DialogDescription>
              <div className="space-y-3">
                <div><Label htmlFor={`login-email-${isStoreOwnerAuth ? 'owner' : 'user'}`}>Email</Label><Input id={`login-email-${isStoreOwnerAuth ? 'owner' : 'user'}`} type="email" placeholder="you@example.com" required value={email} onChange={(e) => setEmail(e.target.value)} /></div>
                <div><Label htmlFor={`login-password-${isStoreOwnerAuth ? 'owner' : 'user'}`}>Password</Label><Input id={`login-password-${isStoreOwnerAuth ? 'owner' : 'user'}`} type="password" placeholder="••••••••" required value={password} onChange={(e) => setPassword(e.target.value)} /></div>
              </div>
              <Button type="submit" className="w-full bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 text-white" disabled={isLoading}>{isLoading ? 'Logging in...' : 'Login'}</Button>
            </form>
          ) : (
            <form onSubmit={handleSignupSubmit} className="space-y-4">
              <DialogTitle className="text-2xl font-bold text-center mb-1 text-slate-800 dark:text-slate-100">{title || defaultTitle}</DialogTitle>
              <DialogDescription className="text-center mb-4 text-slate-600 dark:text-slate-400">{description || defaultDescription}</DialogDescription>
              <div className="space-y-3">
                <div><Label htmlFor={`signup-name-${isStoreOwnerAuth ? 'owner' : 'user'}`}>Full Name</Label><Input id={`signup-name-${isStoreOwnerAuth ? 'owner' : 'user'}`} type="text" placeholder={isStoreOwnerAuth ? "Store Name or Owner Name" : "Your Name"} required value={name} onChange={(e) => setName(e.target.value)} /></div>
                <div><Label htmlFor={`signup-email-${isStoreOwnerAuth ? 'owner' : 'user'}`}>Email</Label><Input id={`signup-email-${isStoreOwnerAuth ? 'owner' : 'user'}`} type="email" placeholder="you@example.com" required value={email} onChange={(e) => setEmail(e.target.value)} /></div>
                <div><Label htmlFor={`signup-password-${isStoreOwnerAuth ? 'owner' : 'user'}`}>Password</Label><Input id={`signup-password-${isStoreOwnerAuth ? 'owner' : 'user'}`} type="password" placeholder="••••••••" required value={password} onChange={(e) => setPassword(e.target.value)} /></div>
              </div>
              <Button type="submit" className="w-full bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 text-white" disabled={isLoading}>{isLoading ? 'Creating Account...' : 'Create Account'}</Button>
            </form>
          )}

          {!isStoreOwnerAuth && (
            <>
              <div className="relative my-6"><div className="absolute inset-0 flex items-center"><span className="w-full border-t border-slate-300 dark:border-slate-700" /></div><div className="relative flex justify-center text-xs uppercase"><span className="bg-card px-2 text-muted-foreground">Or continue with</span></div></div>
              
              <div className="grid grid-cols-2 gap-4">
                <Button variant="outline" onClick={() => onSocialLogin('Google')}><GoogleIcon className="mr-2 h-4 w-4" /> Google</Button>
                <Button variant="outline" onClick={() => onSocialLogin('Apple')}><AppleIcon className="mr-2 h-4 w-4" /> Apple</Button>
              </div>
              <Button variant="outline" className="w-full mt-4" onClick={() => setCurrentView('phone')}>
                  <Phone className="mr-2 h-4 w-4" /> Continue with Phone
              </Button>
            </>
          )}
        </motion.div>
      </AnimatePresence>
    </Tabs>
  );

  const renderPhoneLogin = () => (
     <motion.div
        key="phone"
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: 20 }}
        transition={{ duration: 0.2 }}
        className="p-6"
    >
        <DialogTitle className="text-2xl font-bold text-center mb-1 text-slate-800 dark:text-slate-100">Enter Phone Number</DialogTitle>
        <DialogDescription className="text-center mb-6 text-slate-600 dark:text-slate-400">We'll send you a confirmation code.</DialogDescription>
        <form onSubmit={handlePhoneSubmit} className="space-y-4">
            <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input id="phone" type="tel" placeholder="+91 12345 67890" required value={phoneNum} onChange={e => setPhoneNum(e.target.value)} />
            </div>
            <Button type="submit" className="w-full bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 text-white">Send Code</Button>
            <Button variant="link" className="w-full text-purple-600 dark:text-purple-400" onClick={() => setCurrentView('main')}>Back to login options</Button>
        </form>
    </motion.div>
  );

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChangeWithReset}>
      <DialogContent className="p-0 max-w-md border-0 bg-card shadow-2xl" onInteractOutside={() => handleOpenChangeWithReset(false)}>
        <AnimatePresence mode="wait">
             {currentView === 'main' ? renderMainContent() : renderPhoneLogin()}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
};

export default AuthModal;