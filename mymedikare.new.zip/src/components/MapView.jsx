import React, { useEffect, useRef, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import { motion } from 'framer-motion';
import { MapPin, Star, Clock, Phone, Navigation as NavigationIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import L from 'leaflet';
import 'leaflet-routing-machine';
import 'leaflet-routing-machine/dist/leaflet-routing-machine.css';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const pharmacyIcon = new L.Icon({
  iconUrl: 'data:image/svg+xml;base64,' + btoa(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#8B5CF6" width="36" height="36">
      <path d="M20 6h-3V4c0-2.21-1.79-4-4-4S9 1.79 9 4v2H6c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-8-2c1.1 0 2 .9 2 2v2h-4V4c0-1.1.9-2 2-2zm3 11h-2v2c0 .55-.45 1-1 1s-1-.45-1-1v-2H9c-.55 0-1-.45-1-1s.45-1 1-1h2v-2c0-.55.45-1 1-1s1 .45 1 1v2h2c.55 0 1 .45 1 1s-.45 1-1 1z"/>
    </svg>
  `),
  iconSize: [36, 36],
  iconAnchor: [18, 36],
  popupAnchor: [0, -36],
});

const userIcon = new L.Icon({
  iconUrl: 'data:image/svg+xml;base64,' + btoa(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#3B82F6" width="30" height="30">
      <circle cx="12" cy="10" r="7" fill="#3B82F6" stroke="#ffffff" stroke-width="2"/>
      <path d="M12 22s8-4.5 8-12a8 8 0 0 0-16 0c0 7.5 8 12 8 12z" fill="#3B82F6" stroke="#ffffff" stroke-width="2" opacity="0.5"/>
       <circle cx="12" cy="10" r="3" fill="#ffffff"/>
    </svg>
  `),
  iconSize: [30, 30],
  iconAnchor: [15, 30],
});

function MapUpdater({ userLocation, defaultCenter, defaultZoom, selectedStoreForRoute }) {
  const map = useMap();
  const routingControlRef = useRef(null);

  useEffect(() => {
    if (selectedStoreForRoute && userLocation && selectedStoreForRoute.coordinates) {
      if (routingControlRef.current) {
        map.removeControl(routingControlRef.current);
      }
      routingControlRef.current = L.Routing.control({
        waypoints: [
          L.latLng(userLocation.lat, userLocation.lng),
          L.latLng(selectedStoreForRoute.coordinates[0], selectedStoreForRoute.coordinates[1])
        ],
        routeWhileDragging: true,
        showAlternatives: false,
        lineOptions: {
            styles: [{color: '#6366F1', opacity: 0.8, weight: 6}]
        },
        createMarker: function() { return null; } 
      }).addTo(map);
      
    } else if (!selectedStoreForRoute && routingControlRef.current) {
        map.removeControl(routingControlRef.current);
        routingControlRef.current = null;
        if (defaultCenter) map.setView([defaultCenter.lat, defaultCenter.lng], defaultZoom || 7);
    }
  }, [map, selectedStoreForRoute, userLocation, defaultCenter, defaultZoom]);
  
  useEffect(() => { 
    if (!selectedStoreForRoute) { 
        if (defaultCenter) {
            map.setView([defaultCenter.lat, defaultCenter.lng], defaultZoom || 7);
        } else if (userLocation) {
            map.setView([userLocation.lat, userLocation.lng], 13);
        }
    }
  }, [map, defaultCenter, defaultZoom, userLocation, selectedStoreForRoute]);

  return null;
}


function MapView({ stores, userLocation, onStoreSelect, defaultCenter: propDefaultCenter, defaultZoom: propDefaultZoom }) {
  const [selectedStoreForRoute, setSelectedStoreForRoute] = useState(null);
  
  const mapDefaultCenter = propDefaultCenter ? [propDefaultCenter.lat, propDefaultCenter.lng] : (userLocation ? [userLocation.lat, userLocation.lng] : [20.9517, 85.0985]);
  const mapDefaultZoom = propDefaultZoom || (userLocation ? 13 : 7);

  const handleGetDirectionsPopup = (e, store) => {
    e.stopPropagation();
    if (userLocation && store.coordinates) {
      const { lat: userLat, lng: userLng } = userLocation;
      const [storeLat, storeLng] = store.coordinates;
      const googleMapsUrl = `https://www.google.com/maps/dir/?api=1&origin=${userLat},${userLng}&destination=${storeLat},${storeLng}&travelmode=driving`;
      window.open(googleMapsUrl, '_blank');
      setSelectedStoreForRoute(store);
    } else {
      toast({
        title: "Cannot get directions",
        description: "User location or store location is missing.",
        variant: "destructive"
      });
    }
  };
  
  const handleCallStorePopup = (e) => {
    e.stopPropagation();
    const dummyIndianPhoneNumber = "+918144349805";
    window.location.href = `tel:${dummyIndianPhoneNumber}`;
     toast({
        title: "Calling Store",
        description: `Dialing ${dummyIndianPhoneNumber}. This feature isn't fully implemented yet—but don't worry! You can request live call integration in your next prompt! 🚀`
    });
  };


  const handleClearRoute = () => {
    setSelectedStoreForRoute(null);
  };

  return (
    <div className="h-full w-full relative">
      <MapContainer
        center={mapDefaultCenter}
        zoom={mapDefaultZoom}
        className="h-full w-full rounded-xl"
        zoomControl={true}
        scrollWheelZoom={true}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
          url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png"
        />
        
        <MapUpdater 
            userLocation={userLocation} 
            defaultCenter={propDefaultCenter} 
            defaultZoom={propDefaultZoom}
            selectedStoreForRoute={selectedStoreForRoute}
        />

        {userLocation && (
          <Marker position={[userLocation.lat, userLocation.lng]} icon={userIcon}>
            <Popup>
              <div className="text-center">
                <p className="font-semibold text-blue-600">Your Location</p>
              </div>
            </Popup>
          </Marker>
        )}

        {stores.map(store => (
          store.coordinates && store.coordinates.length === 2 &&
          <Marker 
            key={store.id} 
            position={store.coordinates} 
            icon={pharmacyIcon}
            eventHandlers={{
              click: (e) => {
                if (onStoreSelect) onStoreSelect(store);
                const map = e.target._map;
                if(map && !selectedStoreForRoute) {
                    map.setView(store.coordinates, 15);
                }
              }
            }}
          >
            <Popup autoPan={false}>
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-1 min-w-[230px]"
              >
                <h3 className="font-bold text-md text-purple-700 mb-1">{store.name}</h3>
                <p className="text-xs text-gray-600 mb-1.5 line-clamp-2">{store.address}</p>
                
                <div className="flex items-center space-x-3 mb-1.5 text-xs">
                  <div className="flex items-center">
                    <Star className="h-3.5 w-3.5 text-yellow-400 fill-current" />
                    <span className="ml-0.5 font-medium">{store.rating}</span>
                  </div>
                  <div className="flex items-center text-gray-600">
                    <MapPin className="h-3.5 w-3.5 mr-0.5" />
                    {store.distance} km
                  </div>
                </div>

                <div className="flex items-center text-xs text-gray-600 mb-2">
                  <Clock className="h-3.5 w-3.5 mr-0.5" />
                  {store.openHours}
                </div>

                <div className="flex space-x-1.5">
                  <Button 
                    size="sm"
                    className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white px-2 py-1 h-auto text-xs"
                    onClick={(e) => handleGetDirectionsPopup(e, store)}
                  >
                    <NavigationIcon className="h-3 w-3 mr-1" />
                    Directions
                  </Button>
                   <Button 
                    size="sm"
                    variant="outline"
                    className="flex-1 border-indigo-300 text-indigo-600 hover:bg-indigo-50 px-2 py-1 h-auto text-xs"
                    onClick={(e) => { e.stopPropagation(); onStoreSelect && onStoreSelect(store); }}
                  >
                    Details
                  </Button>
                  <Button 
                    size="sm"
                    variant="outline"
                    className="border-green-400 text-green-600 hover:bg-green-50 px-2 py-1 h-auto text-xs"
                    onClick={handleCallStorePopup}
                  >
                    <Phone className="h-3 w-3" />
                  </Button>
                </div>
              </motion.div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>

      {selectedStoreForRoute && (
         <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            onClick={handleClearRoute}
            className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-red-500 text-white px-4 py-2 rounded-lg shadow-lg z-[1000] text-sm hover:bg-red-600 transition-colors"
          >
            Clear Route
          </motion.button>
      )}

      <motion.div 
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm p-3 rounded-lg shadow-lg z-[1000]"
      >
        <h4 className="font-semibold text-sm mb-2">Legend</h4>
        <div className="space-y-1 text-xs">
          <div className="flex items-center">
            <img src={userIcon.options.iconUrl} alt="User Icon" className="w-4 h-4 mr-1.5" />
            <span>Your Location</span>
          </div>
          <div className="flex items-center">
            <img src={pharmacyIcon.options.iconUrl} alt="Pharmacy Icon" className="w-4 h-4 mr-1.5" />
            <span>Pharmacy</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default MapView;