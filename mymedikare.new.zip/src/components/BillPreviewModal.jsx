import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { X, Printer, Download, Share2 } from 'lucide-react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { toast } from '@/components/ui/use-toast';

const BillPreviewModal = ({ isOpen, onOpenChange, billDetails }) => {
  const billContentRef = useRef(null);
  const AppLogo = "https://storage.googleapis.com/hostinger-horizons-assets-prod/9e7c0e90-d1ac-4b7d-957f-05928bb6595e/636587a4ca4ab1e68beb3c7021dbc5d4.png";

  if (!isOpen || !billDetails) return null;

  const { type, storeName, storeAddress, storePhone, customerName, customerPhone, doctorName, items, subtotal, gstAmount, total, date, billNo, distributorName, invoiceNumber } = billDetails;

  const isSaleBill = type === 'Sale';

  const handleDownloadPdf = async () => {
    const input = billContentRef.current;
    if (!input) return;

    try {
      const canvas = await html2canvas(input, { scale: 2, backgroundColor: '#ffffff' });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = canvas.width;
      const imgHeight = canvas.height;
      const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
      const imgX = (pdfWidth - imgWidth * ratio) / 2;
      const imgY = 10; 

      pdf.addImage(imgData, 'PNG', imgX, imgY, imgWidth * ratio, imgHeight * ratio);
      pdf.save(`${isSaleBill ? 'Invoice' : 'StockReceipt'}-${billNo}.pdf`);
      toast({ title: "Success", description: "Bill downloaded as PDF." });
    } catch (error) {
      console.error("Error generating PDF:", error);
      toast({ title: "Error", description: "Failed to download PDF.", variant: "destructive" });
    }
  };
  
  const handlePrint = () => {
    toast({
        title: "🚧 Feature In Progress",
        description: "Printing directly will be enabled soon! For now, please download the PDF and print. 🚀",
    });
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `${isSaleBill ? 'Invoice' : 'Stock Receipt'} from ${storeName}`,
        text: `Check out this ${isSaleBill ? 'invoice' : 'receipt'} for bill/invoice no: ${billNo}`,
        url: window.location.href, // Or a link to a downloadable PDF if hosted
      })
      .then(() => toast({title: "Shared!", description:"Bill details shared."}))
      .catch((error) => console.error('Error sharing:', error));
    } else {
      toast({
        title: "Share Not Supported",
        description: "Your browser doesn't support direct sharing. Try downloading the PDF.",
        variant: "destructive"
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent 
        className="w-full max-w-2xl p-0 border-0 bg-slate-50 dark:bg-slate-900 rounded-xl shadow-2xl"
        onInteractOutside={(e) => { onOpenChange(false); }}
      >
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="max-h-[90vh] flex flex-col"
        >
          <DialogHeader className="p-6 sticky top-0 bg-slate-100 dark:bg-slate-800 rounded-t-xl border-b border-slate-200 dark:border-slate-700 z-10">
            <div className="flex items-center justify-between">
              <DialogTitle className="text-2xl font-bold text-slate-800 dark:text-slate-100">
                {isSaleBill ? "Invoice" : "Stock Receipt"} Preview
              </DialogTitle>
              <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)} className="rounded-full text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200">
                <X className="h-5 w-5" />
              </Button>
            </div>
            <DialogDescription className="text-sm text-slate-500 dark:text-slate-400">
              Review the details below. You can print or download this document.
            </DialogDescription>
          </DialogHeader>
          
          <div className="p-6 overflow-y-auto flex-grow" ref={billContentRef}>
            <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-md border border-slate-200 dark:border-slate-700 min-w-[700px]">
              {/* Header Section */}
              <div className="flex justify-between items-start pb-4 border-b border-slate-200 dark:border-slate-700 mb-4">
                <div>
                  <div className="flex items-center mb-2">
                    <img src={AppLogo} alt="MyMedikare Logo" className="h-10 mr-2" />
                    <p className="text-2xl font-bold text-slate-800 dark:text-slate-100">{storeName}</p>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{storeAddress}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Phone: {storePhone}</p>
                </div>
                <div className="text-right">
                  <h2 className="text-3xl font-bold uppercase text-purple-600 dark:text-purple-400 mb-1">{isSaleBill ? "INVOICE" : "STOCK RECEIPT"}</h2>
                  <p className="text-xs text-slate-600 dark:text-slate-300"><strong>{isSaleBill ? "Invoice No" : "Receipt No"}:</strong> {billNo}</p>
                  <p className="text-xs text-slate-600 dark:text-slate-300"><strong>Date:</strong> {date}</p>
                </div>
              </div>

              {/* Buyer/Distributor Details */}
              <div className="grid grid-cols-2 gap-4 mb-6 text-xs">
                <div>
                  <p className="font-semibold text-slate-700 dark:text-slate-200 mb-0.5">{isSaleBill ? "Bill To:" : "Received From (Distributor):"}</p>
                  <p className="text-slate-600 dark:text-slate-300">{isSaleBill ? customerName : distributorName}</p>
                  {isSaleBill && customerPhone && <p className="text-slate-600 dark:text-slate-300">Phone: {customerPhone}</p>}
                </div>
                {isSaleBill && (
                  <div className="text-right">
                    <p className="font-semibold text-slate-700 dark:text-slate-200 mb-0.5">Doctor:</p>
                    <p className="text-slate-600 dark:text-slate-300">Dr. {doctorName}</p>
                  </div>
                )}
                 {!isSaleBill && invoiceNumber && (
                  <div className="text-right">
                    <p className="font-semibold text-slate-700 dark:text-slate-200 mb-0.5">Purchase Invoice No:</p>
                    <p className="text-slate-600 dark:text-slate-300">{invoiceNumber}</p>
                  </div>
                )}
              </div>

              {/* Items Table */}
              <table className="w-full text-xs mb-6">
                <thead className="bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                  <tr>
                    <th className="p-2 text-left font-semibold w-[5%]">#</th>
                    <th className="p-2 text-left font-semibold w-[35%]">Medicine Name</th>
                    <th className="p-2 text-left font-semibold w-[15%]">Batch No.</th>
                    <th className="p-2 text-center font-semibold w-[10%]">Exp. Date</th>
                    <th className="p-2 text-center font-semibold w-[10%]">Qty</th>
                    <th className="p-2 text-right font-semibold w-[10%]">{isSaleBill ? "MRP" : "Cost"} (₹)</th>
                    <th className="p-2 text-right font-semibold w-[15%]">Amount (₹)</th>
                  </tr>
                </thead>
                <tbody className="text-slate-700 dark:text-slate-200">
                  {items.map((item, index) => (
                    <tr key={index} className="border-b border-slate-100 dark:border-slate-700">
                      <td className="p-2">{index + 1}</td>
                      <td className="p-2">{item.medName}</td>
                      <td className="p-2">{item.batch || 'N/A'}</td>
                      <td className="p-2 text-center">{item.exp || 'N/A'}</td>
                      <td className="p-2 text-center">{item.qty}</td>
                      <td className="p-2 text-right">{Number(item.price).toFixed(2)}</td>
                      <td className="p-2 text-right">{Number(item.amount).toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Totals Section */}
               <div className="flex justify-end mb-6">
                <div className="w-full max-w-xs text-xs">
                  {isSaleBill && (
                    <>
                    <div className="flex justify-between py-1">
                        <span className="text-slate-600 dark:text-slate-300">Subtotal:</span>
                        <span className="font-medium text-slate-700 dark:text-slate-200">₹{subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-200 dark:border-slate-700">
                        <span className="text-slate-600 dark:text-slate-300">GST (12%):</span>
                        <span className="font-medium text-slate-700 dark:text-slate-200">₹{gstAmount.toFixed(2)}</span>
                    </div>
                    </>
                  )}
                  <div className="flex justify-between pt-1 font-bold text-sm text-slate-800 dark:text-slate-100">
                    <span>Total Amount:</span>
                    <span>₹{total.toFixed(2)}</span>
                  </div>
                </div>
              </div>
              
              {/* Footer Notes */}
              <div className="text-xs text-slate-500 dark:text-slate-400 border-t border-slate-200 dark:border-slate-700 pt-4">
                <p>Thank you for your business!</p>
                <p>All disputes subject to {storeAddress.split(',').pop()?.trim() || 'local'} jurisdiction.</p>
                <p className="font-semibold mt-2">MyMedikare - Your Health, Our Priority.</p>
              </div>
            </div>
          </div>

          <div className="p-6 bg-slate-100 dark:bg-slate-800 rounded-b-xl border-t border-slate-200 dark:border-slate-700 flex flex-wrap gap-2 justify-end">
            <Button variant="outline" onClick={handlePrint} className="text-purple-600 border-purple-300 hover:bg-purple-50 dark:text-purple-400 dark:border-purple-600 dark:hover:bg-purple-700/30">
              <Printer className="h-4 w-4 mr-2" /> Print
            </Button>
            <Button onClick={handleDownloadPdf} className="bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 text-white">
              <Download className="h-4 w-4 mr-2" /> Download PDF
            </Button>
             <Button variant="outline" onClick={handleShare} className="text-green-600 border-green-300 hover:bg-green-50 dark:text-green-400 dark:border-green-600 dark:hover:bg-green-700/30">
              <Share2 className="h-4 w-4 mr-2" /> Share
            </Button>
          </div>
        </motion.div>
      </DialogContent>
    </Dialog>
  );
};

export default BillPreviewModal;