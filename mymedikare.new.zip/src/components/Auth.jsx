import React from 'react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { User, LogIn, LogOut } from 'lucide-react';

const Auth = ({ user, onLoginClick, onSignupClick, onLogout }) => {
  if (user) {
    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="relative h-10 w-10 rounded-full">
            <Avatar className="h-10 w-10">
              <AvatarImage src={user.avatarUrl || ''} alt={user.name || user.email} />
              <AvatarFallback>{(user.name || user.email).charAt(0).toUpperCase()}</AvatarFallback>
            </Avatar>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56" align="end" forceMount>
          <DropdownMenuLabel className="font-normal">
            <div className="flex flex-col space-y-1">
              <p className="text-sm font-medium leading-none">{user.name}</p>
              <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
            </div>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={onLogout} className="cursor-pointer">
            <LogOut className="mr-2 h-4 w-4" />
            <span>Log out</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    );
  }

  return (
    <div className="flex items-center space-x-2">
      <Button
        onClick={onLoginClick}
        variant="ghost"
        className="text-white hover:bg-white/10 focus:bg-white/10 px-2 md:px-3 text-sm hidden sm:flex"
        size="sm"
      >
        <LogIn className="h-4 w-4 mr-2" />
        Login
      </Button>
      <Button
        onClick={onSignupClick}
        className="bg-white/20 hover:bg-white/30 text-white border border-transparent hover:border-white/30 px-2 md:px-4 text-sm"
        size="sm"
      >
        <User className="h-4 w-4 mr-0 sm:mr-2" />
        <span className="hidden sm:inline">Sign Up</span>
      </Button>
    </div>
  );
};

export default Auth;