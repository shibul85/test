import React from 'react';
import { motion } from 'framer-motion';
import { Search, Map, BrainCircuit } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';

const TabNavigation = ({ activeTab, onTabChange, onScanPrescriptionRequest }) => {
  const tabs = [
    { value: 'search', label: 'List View', icon: Search },
    { value: 'map', label: 'Map View', icon: Map },
    { value: 'scanner', label: 'AI Scan', icon: BrainCircuit },
  ];

  const handleTabChange = (value) => {
    if (value === 'scanner') {
      onScanPrescriptionRequest(); 
    } else {
      onTabChange(value);
    }
  };


  return (
    <Tabs value={activeTab} onValueChange={handleTabChange} className="mb-6">
      <TabsList className="grid w-full grid-cols-3 p-1 bg-white/70 dark:bg-slate-800/50 backdrop-blur-sm rounded-xl shadow-inner border border-slate-200 dark:border-slate-700">
        {tabs.map((tab) => (
          <TabsTrigger
            key={tab.value}
            value={tab.value}
            className={`relative flex-1 py-2.5 px-3 md:py-3 md:px-4 rounded-lg font-medium transition-all text-sm md:text-base
              data-[state=active]:text-purple-700 dark:data-[state=active]:text-purple-300 
              data-[state=inactive]:text-slate-600 dark:data-[state=inactive]:text-slate-400 
              data-[state=inactive]:hover:text-purple-600 dark:data-[state=inactive]:hover:text-purple-400 
              focus-visible:ring-2 focus-visible:ring-purple-400 focus-visible:ring-offset-2 focus-visible:ring-offset-background`}
          >
            {activeTab === tab.value && (
              <motion.div
                layoutId="activeTabIndicatorMyMedikare"
                className="absolute inset-0 bg-white dark:bg-slate-700/60 rounded-lg shadow-md z-0 border border-slate-200 dark:border-slate-600"
                transition={{ type: 'spring', stiffness: 350, damping: 30 }}
              />
            )}
            <span className="relative z-10 flex items-center justify-center">
              <tab.icon className="h-4 w-4 md:h-5 md:w-5 mr-1.5 md:mr-2" />
              {tab.label}
            </span>
          </TabsTrigger>
        ))}
      </TabsList>
    </Tabs>
  );
};

export default TabNavigation;