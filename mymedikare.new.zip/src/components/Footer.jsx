import React from 'react';
import { Mail, Phone, MapPin, Heart, Package, ShoppingCart, FileText } from 'lucide-react';

const Footer = ({ email, phone, onAboutClick, onInventoryClick, onHealthBlogClick }) => {
  const AppLogo = "https://storage.googleapis.com/hostinger-horizons-assets-prod/9e7c0e90-d1ac-4b7d-957f-05928bb6595e/636587a4ca4ab1e68beb3c7021dbc5d4.png";
  
  const services = [
    { name: "Medicine Search", path: "#" },
    { name: "Store Locator", path: "#" },
    { name: "AI Prescription Scan", path: "#" },
  ];

  const companyLinks = [
    { name: "About Us", isButton: true, action: onAboutClick },
    { name: "Contact", path: `mailto:${email}` },
    { name: "Privacy Policy", path: "#" },
    { name: "Terms of Service", path: "#" },
  ];

  return (
    <footer className="bg-slate-800 dark:bg-slate-900 text-slate-300 dark:text-slate-400 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
          <div>
            <div className="flex items-center mb-4">
              <img src={AppLogo} alt="MyMedikare Logo" className="h-10 w-auto mr-3 filter brightness-0 invert dark:brightness-100 dark:invert-0" />
              <span className="text-2xl font-bold text-white dark:text-slate-100">MyMedikare</span>
            </div>
            <p className="text-sm leading-relaxed">
              Your trusted partner in finding medicines quickly and easily across Odisha. We're dedicated to your health and well-being.
            </p>
          </div>

          <div>
            <p className="text-lg font-semibold text-white dark:text-slate-200 mb-4">Our Services</p>
            <ul className="space-y-2">
              {services.map((service) => (
                <li key={service.name}>
                  <a href={service.path} className="text-sm hover:text-sky-400 dark:hover:text-sky-300 transition-colors duration-200">
                    {service.name}
                  </a>
                </li>
              ))}
               <li>
                  <button onClick={onInventoryClick} className="flex items-center text-sm hover:text-sky-400 dark:hover:text-sky-300 transition-colors duration-200">
                    <ShoppingCart className="h-4 w-4 mr-2" />
                    Store Owner Portal
                  </button>
                </li>
                 <li>
                  <button onClick={onHealthBlogClick} className="flex items-center text-sm hover:text-sky-400 dark:hover:text-sky-300 transition-colors duration-200">
                    <FileText className="h-4 w-4 mr-2" />
                    Health Blog & Tips
                  </button>
                </li>
            </ul>
          </div>

          <div>
            <p className="text-lg font-semibold text-white dark:text-slate-200 mb-4">Company</p>
            <ul className="space-y-2">
              {companyLinks.map((link) => (
                <li key={link.name}>
                  {link.isButton ? (
                    <button onClick={link.action} className="text-sm hover:text-sky-400 dark:hover:text-sky-300 transition-colors duration-200 text-left w-full">
                      {link.name}
                    </button>
                  ) : (
                    <a href={link.path} className="text-sm hover:text-sky-400 dark:hover:text-sky-300 transition-colors duration-200">
                      {link.name}
                    </a>
                  )}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-lg font-semibold text-white dark:text-slate-200 mb-4">Get in Touch</p>
            <ul className="space-y-3">
              <li className="flex items-start text-sm">
                <Mail className="h-5 w-5 mr-3 mt-0.5 text-sky-400 dark:text-sky-500 flex-shrink-0" />
                <a href={`mailto:${email}`} className="hover:text-sky-400 dark:hover:text-sky-300 transition-colors duration-200 break-all">{email}</a>
              </li>
              <li className="flex items-start text-sm">
                <Phone className="h-5 w-5 mr-3 mt-0.5 text-sky-400 dark:text-sky-500 flex-shrink-0" />
                <a href={`tel:${phone}`} className="hover:text-sky-400 dark:hover:text-sky-300 transition-colors duration-200">{phone}</a>
              </li>
              <li className="flex items-start text-sm">
                <MapPin className="h-5 w-5 mr-3 mt-0.5 text-sky-400 dark:text-sky-500 flex-shrink-0" />
                <span>Bhubaneswar, Odisha, India</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-700 dark:border-slate-600 pt-8 text-center">
          <p className="text-sm">
            &copy; {new Date().getFullYear()} MyMedikare. All rights reserved.
          </p>
          <p className="text-xs mt-2 flex items-center justify-center">
            Made with <Heart className="h-4 w-4 mx-1 text-red-500 fill-current" /> in India for a healthier Odisha.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;