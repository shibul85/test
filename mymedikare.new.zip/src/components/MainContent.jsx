import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, X, BrainCircuit, FlaskConical } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import MapView from '@/components/MapView';
import StoreList from '@/components/StoreList';
import TabNavigation from '@/components/TabNavigation';

const MainContent = ({
  logic,
  activeTab,
  onTabChange,
  onSelectStore,
  onScanPrescriptionRequest
}) => {
  const {
    searchQuery,
    stores,
    isLoading,
    suggestions,
    showSuggestions,
    selectedCity,
    userLocation,
    defaultOdishaLocation,
    handleSearchInputChange,
    handleSuggestionClick,
    handleSearchMedicines,
    clearSearch,
    setShowSuggestions,
    searchType,
    handleSearchTypeChange,
    diseaseSuggestions,
    showDiseaseSuggestions,
    handleDiseaseSuggestionClick,
  } = logic;
  
  const currentMapCenter = selectedCity ? selectedCity.coordinates : defaultOdishaLocation;
  const currentMapZoom = selectedCity ? selectedCity.zoom : 7;
  
  const isMedicineSearch = searchType === 'medicine';
  const isDiseaseSearch = searchType === 'disease';
  const isCompositionSearch = searchType === 'composition';

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-6">
      <motion.div
        initial={{ y: 30, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.5 }}
        className="mb-6 relative"
      >
        <Card className="p-4 md:p-6 bg-white/90 dark:bg-slate-800/70 backdrop-blur-lg border-slate-200 dark:border-slate-700 shadow-xl rounded-xl">
          <div className="flex items-center mb-3 space-x-2 flex-wrap">
            <Button 
              variant={isMedicineSearch ? "default" : "outline"}
              size="sm"
              onClick={() => handleSearchTypeChange('medicine')}
              className={`${isMedicineSearch ? "bg-purple-600 hover:bg-purple-700 text-white dark:bg-purple-500 dark:hover:bg-purple-600" : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700"} transition-colors mb-2 md:mb-0`}
            >
              Search Medicine
            </Button>
            <Button 
              variant={isDiseaseSearch ? "default" : "outline"}
              size="sm"
              onClick={() => handleSearchTypeChange('disease')}
              className={`${isDiseaseSearch ? "bg-purple-600 hover:bg-purple-700 text-white dark:bg-purple-500 dark:hover:bg-purple-600" : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700"} transition-colors mb-2 md:mb-0`}
            >
              Search by Disease
            </Button>
            <Button 
              variant={isCompositionSearch ? "default" : "outline"}
              size="sm"
              onClick={() => handleSearchTypeChange('composition')}
              className={`${isCompositionSearch ? "bg-purple-600 hover:bg-purple-700 text-white dark:bg-purple-500 dark:hover:bg-purple-600" : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700"} transition-colors mb-2 md:mb-0`}
            >
               <FlaskConical className="h-4 w-4 mr-2" /> Search by Composition
            </Button>
          </div>
          <div className="flex flex-col md:flex-row gap-3 items-center">
            <div className="flex-1 relative w-full">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400 dark:text-slate-500" />
              <Input
                placeholder={
                  isMedicineSearch ? `Search medicines in ${selectedCity ? selectedCity.name : 'Odisha'}...` :
                  isDiseaseSearch ? `Search diseases in ${selectedCity ? selectedCity.name : 'Odisha'}...` :
                  `Search by composition (e.g., Paracetamol) in ${selectedCity ? selectedCity.name : 'Odisha'}...`
                }
                value={searchQuery}
                onChange={(e) => handleSearchInputChange(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearchMedicines()}
                onFocus={() => searchQuery.length > 1 && (isMedicineSearch || isCompositionSearch ? setShowSuggestions(true) : logic.setShowDiseaseSuggestions(true))}
                className="h-12 text-base pl-11 pr-10 search-glow border-2 border-slate-200 dark:border-slate-700 focus:border-purple-400 dark:focus:border-purple-500 focus:ring-purple-400 dark:focus:ring-purple-500 rounded-lg bg-white dark:bg-slate-800"
              />
              {searchQuery && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
                  onClick={clearSearch}
                >
                  <X className="h-5 w-5" />
                </Button>
              )}
              <AnimatePresence>
                {(isMedicineSearch || isCompositionSearch) && showSuggestions && suggestions.length > 0 && (
                  <motion.ul
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="absolute z-30 w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md shadow-lg mt-1 max-h-72 overflow-y-auto"
                  >
                    {suggestions.map((suggestion, index) => (
                      <li
                        key={index}
                        className="px-4 py-3 hover:bg-purple-50 dark:hover:bg-purple-700/30 cursor-pointer text-slate-700 dark:text-slate-200 text-sm"
                        onClick={() => handleSuggestionClick(suggestion.name)}
                      >
                        <p className="font-medium">{suggestion.name}</p>
                        {suggestion.composition && <p className="text-xs text-slate-500 dark:text-slate-400">Composition: {suggestion.composition}</p>}
                        {isMedicineSearch && <p className="text-xs text-slate-500 dark:text-slate-400">{suggestion.description}</p>}
                      </li>
                    ))}
                  </motion.ul>
                )}
                {isDiseaseSearch && showDiseaseSuggestions && diseaseSuggestions.length > 0 && (
                    <motion.ul
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="absolute z-30 w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md shadow-lg mt-1 max-h-72 overflow-y-auto"
                    >
                      {diseaseSuggestions.map((suggestion, index) => (
                        <li
                          key={index}
                          className="px-4 py-3 hover:bg-purple-50 dark:hover:bg-purple-700/30 cursor-pointer text-slate-700 dark:text-slate-200 text-sm"
                          onClick={() => handleDiseaseSuggestionClick(suggestion)}
                        >
                          {suggestion}
                        </li>
                      ))}
                    </motion.ul>
                )}
              </AnimatePresence>
            </div>
            <Button
              onClick={() => handleSearchMedicines()}
              disabled={isLoading}
              className="h-12 px-6 bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 text-white font-semibold rounded-lg text-base w-full md:w-auto"
              size="lg"
            >
              {isLoading && searchQuery ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="flex items-center justify-center"
                >
                  <Search className="h-5 w-5" />
                </motion.div>
              ) : (
                 "Search"
              )}
            </Button>
          </div>
        </Card>
      </motion.div>

      <motion.div 
        className="mb-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.5 }}
      >
        <Card 
          className="p-3 md:p-4 bg-white/90 dark:bg-slate-800/70 backdrop-blur-lg border-slate-200 dark:border-slate-700 shadow-lg rounded-xl hover:shadow-purple-200/50 dark:hover:shadow-purple-800/50 transition-shadow cursor-pointer"
          onClick={onScanPrescriptionRequest}
        >
          <div className="flex items-center justify-center space-x-3">
            <BrainCircuit className="h-6 w-6 md:h-7 md:w-7 text-purple-600 dark:text-purple-400" />
            <span className="text-md md:text-lg font-semibold text-slate-700 dark:text-slate-200">AI Prescription Scanner</span>
            <span className="text-xs bg-purple-100 text-purple-700 dark:bg-purple-700/30 dark:text-purple-300 px-2 py-0.5 rounded-full font-medium">Quick Scan</span>
          </div>
        </Card>
      </motion.div>

      <TabNavigation activeTab={activeTab} onTabChange={onTabChange} onScanPrescriptionRequest={onScanPrescriptionRequest} />

      <AnimatePresence mode="wait">
        {activeTab === 'search' && (
          <motion.div
            key="search"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            onClick={() => {setShowSuggestions(false); logic.setShowDiseaseSuggestions(false);}}
            className="mt-0" 
          >
            <StoreList
              stores={stores}
              isLoading={isLoading}
              searchQuery={searchQuery}
              onSelectStore={onSelectStore}
              userLocation={userLocation || defaultOdishaLocation}
              selectedCityName={selectedCity ? selectedCity.name : "Odisha"}
              searchType={searchType}
            />
          </motion.div>
        )}

        {activeTab === 'map' && (
          <motion.div
            key="map"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="h-[350px] md:h-[550px] rounded-xl overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 mt-0" 
          >
            <MapView
              stores={stores}
              userLocation={userLocation || defaultOdishaLocation}
              onStoreSelect={onSelectStore}
              defaultCenter={currentMapCenter}
              defaultZoom={currentMapZoom}
              key={selectedCity ? selectedCity.name : 'default-map'}
            />
          </motion.div>
        )}
        
      </AnimatePresence>
    </div>
  );
};

export default MainContent;