import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/components/ui/use-toast';
import { X, Plus, Trash2, Printer, Package, ShoppingCart, ArrowRight, LogOut, Info } from 'lucide-react';
import { allMedicines } from '@/data/medicinesData';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const BillItemRow = ({ item, index, handleItemChange, removeItem, suggestions, handleSuggestionClick, availableStock }) => (
  <tr className="border-b dark:border-slate-700 relative hover:bg-slate-50 dark:hover:bg-slate-800/50">
    <td className="px-2 py-2.5 align-top">
      <Input value={item.medName} onChange={e => handleItemChange(index, 'medName', e.target.value)} placeholder="Type to search..." className="bg-white dark:bg-slate-800" />
      {suggestions.length > 0 && item.medName.length > 0 && (
        <motion.div initial={{opacity:0, y:5}} animate={{opacity:1, y:0}} className="absolute z-20 w-full bg-white dark:bg-slate-800 rounded-md shadow-lg mt-1 border dark:border-slate-700 max-h-40 overflow-y-auto">
          {suggestions.map((s, i) => <p key={i} onClick={() => handleSuggestionClick(index, s)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer text-sm">{s.name} <span className="text-xs text-slate-500">({s.stock} left)</span></p>)}
        </motion.div>
      )}
    </td>
    <td className="px-2 py-2.5 align-top"><Input type="number" min="1" max={availableStock > 0 ? availableStock : undefined} value={item.qty} onChange={e => handleItemChange(index, 'qty', e.target.value)} className="bg-white dark:bg-slate-800 w-20 text-center" /></td>
    <td className="px-2 py-2.5 align-top"><Input type="number" step="0.01" value={item.price} onChange={e => handleItemChange(index, 'price', e.target.value)} className="bg-white dark:bg-slate-800 w-24 text-right" /></td>
    <td className="px-2 py-2.5 align-top font-medium text-slate-800 dark:text-slate-100 text-right">{item.amount.toFixed(2)}</td>
    <td className="px-2 py-2.5 align-top text-center">
      <Button variant="ghost" size="icon" onClick={() => removeItem(index)} className="text-red-500 hover:bg-red-100 dark:hover:bg-red-700/30 rounded-full h-8 w-8"><Trash2 className="h-4 w-4" /></Button>
    </td>
  </tr>
);

const InventoryModal = ({ isOpen, onOpenChange, stores, updateStock, onLogout, onShowBill }) => {
  const [customerName, setCustomerName] = useState('');
  const [doctorName, setDoctorName] = useState('Self');
  const [customerPhone, setCustomerPhone] = useState('');
  const [billItems, setBillItems] = useState([{ medName: '', qty: 1, price: 0, amount: 0, batch: '', exp: '' }]);
  
  const [stockInItems, setStockInItems] = useState([{ medName: '', qty: 1, batch: '', exp: '', purchasePrice: 0, mrp: 0 }]);
  const [distributorName, setDistributorName] = useState('');
  const [invoiceNumber, setInvoiceNumber] = useState('');
  
  const [activeSuggestions, setActiveSuggestions] = useState({ type: null, index: -1, list: [] });
  const [selectedStoreId, setSelectedStoreId] = useState(stores.length > 0 ? stores[0].id : null);

  useEffect(() => {
    if (stores.length > 0 && !selectedStoreId) {
      setSelectedStoreId(stores[0].id);
    }
  }, [stores, selectedStoreId]);

  const selectedStore = stores.find(s => s.id === selectedStoreId);

  const handleBillItemChange = (index, field, value) => {
    const newItems = [...billItems];
    const item = newItems[index];
    item[field] = value;
    if (field === 'medName') {
      if (value.length > 0 && selectedStore) {
        const filtered = Object.entries(selectedStore.medicines)
          .filter(([medName]) => medName.toLowerCase().includes(value.toLowerCase()))
          .map(([medName, medDetails]) => ({ name: medName, stock: medDetails.stock, price: medDetails.price }))
          .slice(0, 5);
        setActiveSuggestions({ type: 'bill', index, list: filtered });
      } else {
        setActiveSuggestions({ type: null, index: -1, list: [] });
      }
    }
    if (field === 'qty' || field === 'price') {
      item.amount = (Number(item.qty) || 0) * (Number(item.price) || 0);
    }
    setBillItems(newItems);
  };
  
  const handleStockInItemChange = (index, field, value) => {
    const newItems = [...stockInItems];
    newItems[index][field] = value;
    if (field === 'medName') {
      if (value.length > 0) {
        const filtered = allMedicines
          .filter(med => med.toLowerCase().includes(value.toLowerCase()))
          .map(med => ({ name: med }))
          .slice(0, 5);
        setActiveSuggestions({ type: 'stockin', index, list: filtered });
      } else {
        setActiveSuggestions({ type: null, index: -1, list: [] });
      }
    }
    setStockInItems(newItems);
  };
  
  const handleSuggestionClick = (type, index, suggestion) => {
    if (type === 'bill') {
      const newItems = [...billItems];
      const item = newItems[index];
      item.medName = suggestion.name;
      item.price = suggestion.price || (Math.random() * 300 + 50).toFixed(2);
      item.amount = (Number(item.qty) || 0) * (Number(item.price) || 0);
      item.batch = selectedStore?.medicines[suggestion.name]?.batch || `B${Math.floor(Math.random()*900)+100}`;
      item.exp = selectedStore?.medicines[suggestion.name]?.exp || `${Math.floor(Math.random()*12)+1}/${new Date().getFullYear() + Math.floor(Math.random()*3)+1}`;
      setBillItems(newItems);
    } else { 
      const newItems = [...stockInItems];
      newItems[index].medName = suggestion.name;
      setStockInItems(newItems);
    }
    setActiveSuggestions({ type: null, index: -1, list: [] });
    document.activeElement.blur(); 
  }

  const addBillItem = () => setBillItems([...billItems, { medName: '', qty: 1, price: 0, amount: 0, batch: '', exp: '' }]);
  const removeBillItem = (index) => setBillItems(billItems.filter((_, i) => i !== index));
  
  const addStockInItem = () => setStockInItems([...stockInItems, { medName: '', qty: 1, batch: '', exp: '', purchasePrice: 0, mrp: 0 }]);
  const removeStockInItem = (index) => setStockInItems(stockInItems.filter((_, i) => i !== index));

  const subtotal = billItems.reduce((total, item) => total + item.amount, 0);
  const gstRate = 0.12; 
  const gst = subtotal * gstRate;
  const total = subtotal + gst;

  const resetSaleForm = () => {
    setCustomerName('');
    setCustomerPhone('');
    setDoctorName('Self');
    setBillItems([{ medName: '', qty: 1, price: 0, amount: 0, batch: '', exp: '' }]);
    setActiveSuggestions({ type: null, index: -1, list: [] });
  };
  
  const resetStockInForm = () => {
    setDistributorName('');
    setInvoiceNumber('');
    setStockInItems([{ medName: '', qty: 1, batch: '', exp: '', purchasePrice: 0, mrp: 0 }]);
    setActiveSuggestions({ type: null, index: -1, list: [] });
  }

  const handleFinalizeSale = () => {
    if (!selectedStoreId || !selectedStore) {
      toast({ title: "Error", description: "Please select a valid store.", variant: "destructive" });
      return;
    }
    let allItemsValid = true;
    const validBillItems = billItems.filter(item => item.medName && Number(item.qty) > 0);
    if(validBillItems.length === 0){
        toast({ title: "Empty Bill", description: "Please add items to the bill.", variant: "destructive" });
        return;
    }

    validBillItems.forEach(item => {
      const stockAvailable = selectedStore.medicines[item.medName]?.stock || 0;
      if (Number(item.qty) > stockAvailable) {
        toast({ title: "Insufficient Stock", description: `Not enough ${item.medName} available (${stockAvailable} left). Sale not processed for this item.`, variant: "destructive" });
        allItemsValid = false;
      }
    });

    if (!allItemsValid) return;

    validBillItems.forEach(item => {
      updateStock(selectedStoreId, item.medName, -Math.abs(Number(item.qty)));
    });

    const billData = {
      type: 'Sale',
      storeName: selectedStore.name,
      storeAddress: selectedStore.address,
      storePhone: selectedStore.phone,
      customerName: customerName || "N/A",
      customerPhone: customerPhone || "N/A",
      doctorName,
      items: validBillItems.map(item => ({ ...item, amount: item.qty * item.price })),
      subtotal,
      gstAmount: gst,
      total,
      date: new Date().toLocaleDateString('en-IN'),
      billNo: `INV-${Date.now().toString().slice(-6)}`
    };
    onShowBill(billData);
    
    if (customerPhone.match(/^\d{10}$/)) {
        toast({
            title: "SMS Sent (Simulated)",
            description: `Bill details sent to ${customerPhone}. Link: bill.mymedikare.com/${billData.billNo} 🚀`,
        });
    } else if (customerPhone) {
        toast({
            title: "Invalid Phone (Simulated)",
            description: `Could not send SMS to ${customerPhone}. Please enter a valid 10-digit number.`,
            variant: "destructive"
        });
    }
    
    toast({ title: "Sale Finalized!", description: `Stock updated for ${selectedStore.name}. Bill generated.` });
    resetSaleForm();
  };

  const handleAddStock = () => {
    if (!selectedStoreId || !selectedStore) {
      toast({ title: "Error", description: "Please select a store.", variant: "destructive" });
      return;
    }
    const validStockItems = stockInItems.filter(item => item.medName && Number(item.qty) > 0);
    if(validStockItems.length === 0){
        toast({ title: "Empty Stock List", description: "Please add items to receive.", variant: "destructive" });
        return;
    }

    validStockItems.forEach(item => {
      updateStock(selectedStoreId, item.medName, Math.abs(Number(item.qty)), item.mrp, item.batch, item.exp);
    });
    
    const stockInData = {
      type: 'Stock In',
      storeName: selectedStore.name,
      storeAddress: selectedStore.address,
      distributorName: distributorName || "N/A",
      invoiceNumber: invoiceNumber || `SINV-${Date.now().toString().slice(-6)}`,
      items: validStockItems.map(item => ({ 
          medName: item.medName, 
          qty: item.qty, 
          batch: item.batch, 
          exp: item.exp,
          price: item.purchasePrice, // Using purchasePrice for stock-in
          amount: Number(item.qty) * Number(item.purchasePrice)
      })),
      total: validStockItems.reduce((acc, item) => acc + (Number(item.qty) * Number(item.purchasePrice)),0),
      date: new Date().toLocaleDateString('en-IN'),
      billNo: invoiceNumber || `SINV-${Date.now().toString().slice(-6)}`
    };
    onShowBill(stockInData);

    toast({ title: "Stock Received!", description: `Stock updated for ${selectedStore.name}. Purchase recorded.` });
    resetStockInForm();
  };
  
  const handleLogoutClick = () => {
    onLogout();
    onOpenChange(false);
  };


  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="w-full max-w-5xl p-0 border-0 bg-slate-50 dark:bg-slate-900 rounded-xl shadow-2xl" onInteractOutside={(e) => { e.preventDefault(); onOpenChange(false); }}>
        <motion.div initial={{ opacity: 0, y: 50 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} className="max-h-[90vh] flex flex-col">
          <div className="flex items-center justify-between p-6 bg-slate-100 dark:bg-slate-800 rounded-t-xl border-b dark:border-slate-700 sticky top-0 z-10">
            <div className="flex items-center"><Package className="h-8 w-8 text-purple-600 dark:text-purple-400 mr-3" /><div><h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Inventory Management</h2><p className="text-sm text-slate-500 dark:text-slate-400">Manage sales and stock for {selectedStore ? selectedStore.name : "your store"}</p></div></div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" onClick={handleLogoutClick} className="text-red-600 border-red-300 hover:bg-red-50 dark:text-red-400 dark:border-red-600 dark:hover:bg-red-700/30">
                <LogOut className="h-4 w-4 mr-2"/> Logout
              </Button>
              <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)} className="rounded-full text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"><X className="h-5 w-5" /></Button>
            </div>
          </div>
          
          <div className="p-6 border-b dark:border-slate-700">
            <Label htmlFor="store-select" className="font-semibold text-slate-700 dark:text-slate-200">Select Store</Label>
            <Select onValueChange={(val) => setSelectedStoreId(Number(val))} defaultValue={selectedStoreId ? String(selectedStoreId) : undefined}>
              <SelectTrigger id="store-select" className="w-full md:w-1/2 mt-1 bg-white dark:bg-slate-800">
                <SelectValue placeholder="Select a medical store..." />
              </SelectTrigger>
              <SelectContent className="bg-white dark:bg-slate-800">
                {stores.map(store => <SelectItem key={store.id} value={String(store.id)}>{store.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <div className="px-6 pb-6 flex-grow overflow-y-auto">
            <Tabs defaultValue="billing" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="billing"><ShoppingCart className="h-4 w-4 mr-2" />Sales Bill</TabsTrigger>
                <TabsTrigger value="stock-in"><ArrowRight className="h-4 w-4 mr-2" />Stock In</TabsTrigger>
              </TabsList>
              
              <TabsContent value="billing" className="mt-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div><Label htmlFor="customerName" className="text-sm font-medium text-slate-700 dark:text-slate-200">Customer Name</Label><Input id="customerName" value={customerName} onChange={e => setCustomerName(e.target.value)} placeholder="Name" className="bg-white dark:bg-slate-800 text-sm"/></div>
                  <div><Label htmlFor="customerPhone" className="text-sm font-medium text-slate-700 dark:text-slate-200">Customer Phone</Label><Input id="customerPhone" type="tel" value={customerPhone} onChange={e => setCustomerPhone(e.target.value)} placeholder="10-digit mobile (for SMS)" className="bg-white dark:bg-slate-800 text-sm"/></div>
                  <div><Label htmlFor="doctorName" className="text-sm font-medium text-slate-700 dark:text-slate-200">Prescribed by Dr.</Label><Input id="doctorName" value={doctorName} onChange={e => setDoctorName(e.target.value)} placeholder="Doctor's name" className="bg-white dark:bg-slate-800 text-sm"/></div>
                </div>
                <div className="overflow-x-auto rounded-lg border dark:border-slate-700"><table className="w-full text-sm text-left text-slate-500 dark:text-slate-400">
                  <thead className="text-xs text-slate-700 dark:text-slate-300 uppercase bg-slate-200 dark:bg-slate-700"><tr><th className="px-2 py-3 w-[40%]">Medicine</th><th className="px-2 py-3 w-[10%] text-center">Qty</th><th className="px-2 py-3 w-[15%] text-right">Price (₹)</th><th className="px-2 py-3 w-[15%] text-right">Amount (₹)</th><th className="px-2 py-3 w-[10%]"></th></tr></thead>
                  <tbody>{billItems.map((item, index) => <BillItemRow key={index} item={item} index={index} handleItemChange={handleBillItemChange} removeItem={removeBillItem} suggestions={activeSuggestions.type === 'bill' && activeSuggestions.index === index ? activeSuggestions.list : []} handleSuggestionClick={(idx, sug) => handleSuggestionClick('bill', idx, sug)} availableStock={selectedStore?.medicines[item.medName]?.stock} />)}</tbody>
                </table></div>
                <Button variant="outline" onClick={addBillItem} className="mt-4 text-purple-600 border-purple-300 hover:bg-purple-50 dark:text-purple-400 dark:border-purple-600 dark:hover:bg-purple-700/30"><Plus className="h-4 w-4 mr-2" /> Add Item</Button>
                <div className="flex justify-end pt-6"><div className="w-full max-w-sm space-y-2 text-sm">
                  <div className="flex justify-between"><span className="text-slate-600 dark:text-slate-300">Subtotal</span><span className="font-medium text-slate-800 dark:text-slate-100">₹{subtotal.toFixed(2)}</span></div>
                  <div className="flex justify-between"><span className="text-slate-600 dark:text-slate-300">GST ({ (gstRate * 100).toFixed(0) }%)</span><span className="font-medium text-slate-800 dark:text-slate-100">₹{gst.toFixed(2)}</span></div>
                  <div className="flex justify-between text-lg font-bold text-slate-900 dark:text-white border-t dark:border-slate-700 pt-2 mt-2"><span>Total</span><span>₹{total.toFixed(2)}</span></div>
                </div></div>
                <div className="flex justify-end mt-2"><Button className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white" onClick={handleFinalizeSale}><Printer className="h-4 w-4 mr-2" /> Finalize Sale & View Bill</Button></div>
              </TabsContent>

              <TabsContent value="stock-in" className="mt-4">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div><Label htmlFor="distributorName" className="text-sm font-medium text-slate-700 dark:text-slate-200">Distributor Name</Label><Input id="distributorName" value={distributorName} onChange={e => setDistributorName(e.target.value)} placeholder="Distributor or Supplier" className="bg-white dark:bg-slate-800 text-sm"/></div>
                    <div><Label htmlFor="invoiceNumber" className="text-sm font-medium text-slate-700 dark:text-slate-200">Invoice Number</Label><Input id="invoiceNumber" value={invoiceNumber} onChange={e => setInvoiceNumber(e.target.value)} placeholder="Purchase Invoice No." className="bg-white dark:bg-slate-800 text-sm"/></div>
                 </div>
                 <div className="overflow-x-auto rounded-lg border dark:border-slate-700"><table className="w-full text-sm text-left text-slate-500 dark:text-slate-400">
                  <thead className="text-xs text-slate-700 dark:text-slate-300 uppercase bg-slate-200 dark:bg-slate-700"><tr>
                    <th className="px-2 py-3 w-[30%]">Medicine</th>
                    <th className="px-2 py-3 w-[10%] text-center">Qty</th>
                    <th className="px-2 py-3 w-[15%]">Batch No.</th>
                    <th className="px-2 py-3 w-[15%]">Exp. Date</th>
                    <th className="px-2 py-3 w-[10%] text-right">Cost/Unit</th>
                    <th className="px-2 py-3 w-[10%] text-right">MRP/Unit</th>
                    <th className="px-2 py-3 w-[10%]"></th>
                  </tr></thead>
                  <tbody>{stockInItems.map((item, index) => (
                    <tr key={index} className="border-b dark:border-slate-700 relative hover:bg-slate-50 dark:hover:bg-slate-800/50">
                      <td className="px-2 py-2.5 align-top">
                        <Input value={item.medName} onChange={e => handleStockInItemChange(index, 'medName', e.target.value)} placeholder="Type to search..." className="bg-white dark:bg-slate-800" />
                        {activeSuggestions.type === 'stockin' && activeSuggestions.index === index && activeSuggestions.list.length > 0 && (
                          <motion.div initial={{opacity:0, y:5}} animate={{opacity:1, y:0}} className="absolute z-20 w-full bg-white dark:bg-slate-800 rounded-md shadow-lg mt-1 border dark:border-slate-700 max-h-40 overflow-y-auto">
                            {activeSuggestions.list.map((s, i) => <p key={i} onClick={() => handleSuggestionClick('stockin', index, s)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer text-sm">{s.name}</p>)}
                          </motion.div>
                        )}
                      </td>
                      <td className="px-2 py-2.5 align-top"><Input type="number" min="1" value={item.qty} onChange={e => handleStockInItemChange(index, 'qty', e.target.value)} className="bg-white dark:bg-slate-800 w-20 text-center" /></td>
                      <td className="px-2 py-2.5 align-top"><Input value={item.batch} onChange={e => handleStockInItemChange(index, 'batch', e.target.value)} placeholder="Batch123" className="bg-white dark:bg-slate-800 w-28"/></td>
                      <td className="px-2 py-2.5 align-top"><Input type="text" value={item.exp} onChange={e => handleStockInItemChange(index, 'exp', e.target.value)} placeholder="MM/YYYY" className="bg-white dark:bg-slate-800 w-24"/></td>
                      <td className="px-2 py-2.5 align-top"><Input type="number" step="0.01" value={item.purchasePrice} onChange={e => handleStockInItemChange(index, 'purchasePrice', e.target.value)} className="bg-white dark:bg-slate-800 w-24 text-right"/></td>
                      <td className="px-2 py-2.5 align-top"><Input type="number" step="0.01" value={item.mrp} onChange={e => handleStockInItemChange(index, 'mrp', e.target.value)} className="bg-white dark:bg-slate-800 w-24 text-right"/></td>
                      <td className="px-2 py-2.5 align-top text-center"><Button variant="ghost" size="icon" onClick={() => removeStockInItem(index)} className="text-red-500 hover:bg-red-100 dark:hover:bg-red-700/30 rounded-full h-8 w-8"><Trash2 className="h-4 w-4" /></Button></td>
                    </tr>
                  ))}</tbody>
                </table></div>
                <Button variant="outline" onClick={addStockInItem} className="mt-4 text-purple-600 border-purple-300 hover:bg-purple-50 dark:text-purple-400 dark:border-purple-600 dark:hover:bg-purple-700/30"><Plus className="h-4 w-4 mr-2" /> Add Item</Button>
                <div className="flex justify-end mt-6"><Button className="bg-gradient-to-r from-blue-500 to-sky-600 hover:from-blue-600 hover:to-sky-700 text-white" onClick={handleAddStock}><Package className="h-4 w-4 mr-2" /> Receive Stock & View Details</Button></div>
              </TabsContent>
            </Tabs>
          </div>
        </motion.div>
      </DialogContent>
    </Dialog>
  );
};

export default InventoryModal;