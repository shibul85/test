import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/components/ui/use-toast';
import { X, Plus, Trash2, Printer, Receipt } from 'lucide-react';
import { allMedicines } from '@/data/medicinesData';

const BillingModal = ({ isOpen, onOpenChange }) => {
  const [customerName, setCustomerName] = useState('');
  const [doctorName, setDoctorName] = useState('Self');
  const [billItems, setBillItems] = useState([{ medName: '', qty: 1, price: 0, amount: 0 }]);
  const [suggestions, setSuggestions] = useState([]);

  const handleItemChange = (index, field, value) => {
    const newItems = [...billItems];
    const item = newItems[index];
    item[field] = value;

    if (field === 'medName') {
      if (value.length > 2) {
        const filtered = allMedicines
          .filter(med => med.toLowerCase().includes(value.toLowerCase()))
          .slice(0, 5);
        setSuggestions(filtered);
      } else {
        setSuggestions([]);
      }
    }
    
    if(field === 'qty' || field === 'price') {
        item.amount = (parseFloat(item.qty) || 0) * (parseFloat(item.price) || 0);
    }

    setBillItems(newItems);
  };
  
  const handleSuggestionClick = (index, medName) => {
      const newItems = [...billItems];
      const item = newItems[index];
      item.medName = medName;
      item.price = (Math.random() * 450 + 50).toFixed(2);
      item.amount = (parseFloat(item.qty) || 0) * (parseFloat(item.price) || 0);
      setBillItems(newItems);
      setSuggestions([]);
  }

  const addItem = () => {
    setBillItems([...billItems, { medName: '', qty: 1, price: 0, amount: 0 }]);
  };

  const removeItem = (index) => {
    const newItems = billItems.filter((_, i) => i !== index);
    setBillItems(newItems);
  };
  
  const calculateTotal = () => {
      return billItems.reduce((total, item) => total + item.amount, 0);
  }
  
  const subtotal = calculateTotal();
  const gst = subtotal * 0.12; // Assuming 12% GST
  const total = subtotal + gst;

  const handlePrintBill = () => {
      toast({
          title: "🚧 Feature In Progress",
          description: "Printing and saving bills will be available soon. For now, this is a demo! 🚀",
      });
  }

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent 
        className="w-full max-w-4xl p-0 border-0" 
        onInteractOutside={(e) => { e.preventDefault(); onOpenChange(false); }}
      >
        <motion.div 
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-slate-50 rounded-xl"
        >
            <div className="flex items-center justify-between p-6 bg-slate-100 rounded-t-xl border-b">
                <div className="flex items-center">
                    <Receipt className="h-8 w-8 text-purple-600 mr-3"/>
                    <div>
                        <h2 className="text-2xl font-bold text-slate-800">Medical Store Billing</h2>
                        <p className="text-sm text-slate-500">Create a new bill for a customer</p>
                    </div>
                </div>
                <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)} className="rounded-full">
                    <X className="h-5 w-5" />
                </Button>
            </div>
          
            <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <Label htmlFor="customerName" className="font-semibold text-slate-700">Customer Name</Label>
                    <Input id="customerName" value={customerName} onChange={e => setCustomerName(e.target.value)} placeholder="Enter customer's name" />
                </div>
                <div>
                    <Label htmlFor="doctorName" className="font-semibold text-slate-700">Prescribed by Dr.</Label>
                    <Input id="doctorName" value={doctorName} onChange={e => setDoctorName(e.target.value)} placeholder="Enter doctor's name" />
                </div>
            </div>

            <div className="px-6 pb-6">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-slate-500">
                        <thead className="text-xs text-slate-700 uppercase bg-slate-200">
                            <tr>
                                <th scope="col" className="px-4 py-3 rounded-l-lg w-2/5">Medicine Name</th>
                                <th scope="col" className="px-4 py-3 w-1/5">Quantity</th>
                                <th scope="col" className="px-4 py-3 w-1/5">Price (₹)</th>
                                <th scope="col" className="px-4 py-3 w-1/5">Amount (₹)</th>
                                <th scope="col" className="px-4 py-3 rounded-r-lg"></th>
                            </tr>
                        </thead>
                        <tbody>
                            {billItems.map((item, index) => (
                                <tr key={index} className="border-b relative">
                                    <td className="px-4 py-2">
                                        <Input value={item.medName} onChange={e => handleItemChange(index, 'medName', e.target.value)} placeholder="Type to search..." className="bg-white"/>
                                        {suggestions.length > 0 && (
                                            <div className="absolute z-10 w-full bg-white rounded-md shadow-lg mt-1 border">
                                                {suggestions.map((s, i) => <p key={i} onClick={() => handleSuggestionClick(index, s)} className="p-2 hover:bg-slate-100 cursor-pointer">{s}</p>)}
                                            </div>
                                        )}
                                    </td>
                                    <td className="px-4 py-2"><Input type="number" value={item.qty} onChange={e => handleItemChange(index, 'qty', e.target.value)} className="bg-white w-20"/></td>
                                    <td className="px-4 py-2"><Input type="number" value={item.price} onChange={e => handleItemChange(index, 'price', e.target.value)} className="bg-white w-24" /></td>
                                    <td className="px-4 py-2 font-medium text-slate-800">{item.amount.toFixed(2)}</td>
                                    <td className="px-4 py-2 text-center">
                                        <Button variant="ghost" size="icon" onClick={() => removeItem(index)} className="text-red-500 hover:bg-red-100">
                                            <Trash2 className="h-4 w-4"/>
                                        </Button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                <Button variant="outline" onClick={addItem} className="mt-4 text-purple-600 border-purple-300 hover:bg-purple-50">
                    <Plus className="h-4 w-4 mr-2"/> Add Item
                </Button>
            </div>
            
            <div className="flex justify-end p-6">
                <div className="w-full max-w-sm space-y-2 text-sm">
                    <div className="flex justify-between">
                        <span className="text-slate-600">Subtotal</span>
                        <span className="font-medium text-slate-800">₹{subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-slate-600">GST (12%)</span>
                        <span className="font-medium text-slate-800">₹{gst.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-lg font-bold text-slate-900 border-t pt-2 mt-2">
                        <span>Total</span>
                        <span>₹{total.toFixed(2)}</span>
                    </div>
                </div>
            </div>

            <div className="p-6 bg-slate-100 rounded-b-xl border-t flex justify-end">
                <Button className="bg-gradient-to-r from-purple-600 to-blue-500 text-white" onClick={handlePrintBill}>
                    <Printer className="h-4 w-4 mr-2"/> Print Bill
                </Button>
            </div>
        </motion.div>
      </DialogContent>
    </Dialog>
  );
};

export default BillingModal;