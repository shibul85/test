import React from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Star, Clock, MapPin, Info, AlertTriangle, Navigation, Phone, CheckCircle, XCircle, FlaskConical } from 'lucide-react';
import { calculateDistanceToStore } from '@/lib/locationUtils';
import { toast } from '@/components/ui/use-toast';
import { medicineInfo } from '@/data/medicineInfo';


const StoreList = ({ stores, isLoading, searchQuery, onSelectStore, userLocation, selectedCityName, searchType }) => {
  
  const handleDirectionsClick = (e, store) => {
    e.stopPropagation(); 
    if (userLocation && store.coordinates) {
      const { lat: userLat, lng: userLng } = userLocation;
      const [storeLat, storeLng] = store.coordinates;
      const googleMapsUrl = `https://www.google.com/maps/dir/?api=1&origin=${userLat},${userLng}&destination=${storeLat},${storeLng}&travelmode=driving`;
      window.open(googleMapsUrl, '_blank');
    } else {
      toast({
        title: "Cannot get directions",
        description: "User location or store location is missing.",
        variant: "destructive"
      });
    }
  };

  const handleCallClick = (e) => {
    e.stopPropagation(); 
    const dummyIndianPhoneNumber = "+918144349805";
    window.location.href = `tel:${dummyIndianPhoneNumber}`;
     toast({
        title: "Calling Store",
        description: `Dialing ${dummyIndianPhoneNumber}. This feature isn't fully implemented yet—but don't worry! You can request live call integration in your next prompt! 🚀`
    });
  };

  const isStoreOpenNow = (store) => {
    if (!store.openHours || store.openHours.toLowerCase() === "24/7") return true;
    try {
      const [openTimeStr, closeTimeStr] = store.openHours.split(' - ');
      const now = new Date();
      const currentHour = now.getHours();
      const currentMinute = now.getMinutes();

      const parseTime = (timeStr) => {
        const [time, modifier] = timeStr.split(' ');
        let [hours, minutes] = time.split(':').map(Number);
        if (modifier === 'PM' && hours < 12) hours += 12;
        if (modifier === 'AM' && hours === 12) hours = 0; 
        return { hours, minutes };
      };

      const open = parseTime(openTimeStr);
      const close = parseTime(closeTimeStr);
      
      const currentTimeInMinutes = currentHour * 60 + currentMinute;
      const openTimeInMinutes = open.hours * 60 + open.minutes;
      let closeTimeInMinutes = close.hours * 60 + close.minutes;

      if (closeTimeInMinutes < openTimeInMinutes) { 
        closeTimeInMinutes += 24 * 60;
        if (currentTimeInMinutes < openTimeInMinutes) { 
          return (currentTimeInMinutes + 24*60) < closeTimeInMinutes && (currentTimeInMinutes + 24*60) >= (openTimeInMinutes);
        }
      }
      return currentTimeInMinutes >= openTimeInMinutes && currentTimeInMinutes < closeTimeInMinutes;
    } catch (error) {
      console.error("Error parsing store hours:", error);
      return false; 
    }
  };


  if (isLoading) {
    return (
      <div className="grid gap-4 md:gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {[...Array(8)].map((_, i) => (
          <Card key={i} className="p-5 bg-white/70 backdrop-blur-sm animate-pulse rounded-xl shadow-lg">
            <div className="h-6 bg-slate-200 rounded w-3/4 mb-2"></div>
            <div className="h-4 bg-slate-200 rounded w-1/2 mb-3"></div>
            <div className="h-4 bg-slate-200 rounded w-1/4 mb-4"></div>
            <div className="h-10 bg-slate-200 rounded w-full mb-3"></div>
            <div className="flex space-x-2">
              <div className="h-9 bg-slate-200 rounded flex-1"></div>
              <div className="h-9 bg-slate-200 rounded flex-1"></div>
            </div>
          </Card>
        ))}
      </div>
    );
  }

  if (stores.length === 0 && searchQuery) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center py-16 bg-white/70 backdrop-blur-sm rounded-xl shadow-xl"
      >
        <AlertTriangle className="mx-auto h-16 w-16 text-amber-500 mb-4" />
        <h3 className="text-xl md:text-2xl font-semibold text-slate-700 mb-2">No Results Found</h3>
        <p className="text-slate-500 max-w-md mx-auto">
          We couldn't find "{searchQuery}" in any stores in {selectedCityName}. Try a different {searchType} or check your spelling.
        </p>
      </motion.div>
    );
  }
  
  if (stores.length === 0 && !searchQuery) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center py-16 bg-white/70 backdrop-blur-sm rounded-xl shadow-xl"
      >
        <Info className="mx-auto h-16 w-16 text-sky-500 mb-4" />
        <h3 className="text-xl md:text-2xl font-semibold text-slate-700 mb-2">Start Your Search</h3>
        <p className="text-slate-500 max-w-md mx-auto">
          Enter a {searchType} name in the search bar above to find available pharmacies in {selectedCityName}.
        </p>
      </motion.div>
    );
  }


  return (
    <div className="grid gap-4 md:gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {stores.map((store, index) => {
        const isOpen = isStoreOpenNow(store);
        const medDetails = store.searchedMedicine;
        const medComposition = medDetails && medicineInfo[medDetails.name]?.composition;
        return (
        <motion.div
          key={store.id}
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.03, type: "spring", stiffness: 100 }}
          whileHover={{ y: -6, boxShadow: "0 10px 20px rgba(0,0,0,0.1)"}}
          className="h-full"
        >
          <Card 
            className="medicine-card p-4 md:p-5 cursor-pointer flex flex-col justify-between h-full bg-white/80 backdrop-blur-md border-slate-200 shadow-lg hover:shadow-xl transition-all duration-300 rounded-xl" 
            onClick={() => onSelectStore(store)}
          >
            <div>
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-md md:text-lg font-bold text-slate-800 leading-tight">{store.name}</h3>
                <Badge variant="outline" className="border-sky-300 bg-sky-50 text-sky-700 text-xs whitespace-nowrap ml-2">
                  <MapPin className="h-3 w-3 mr-1" />
                  {userLocation && store.coordinates ? calculateDistanceToStore(store, userLocation) : store.distance} km
                </Badge>
              </div>
              <p className="text-xs text-slate-500 mb-2 line-clamp-2">{store.address}</p>

              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mb-3 text-xs">
                <div className="flex items-center text-slate-700">
                  <Star className="h-3.5 w-3.5 text-yellow-400 fill-current mr-0.5" />
                  <span className="font-medium">{store.rating}</span>
                </div>
                <div className="flex items-center text-slate-600">
                  <Clock className="h-3.5 w-3.5 mr-0.5" />
                  {store.openHours}
                </div>
                 <Badge variant={isOpen ? "default" : "destructive"} className={`text-white ${isOpen ? 'bg-green-500' : 'bg-red-500'} `}>
                  {isOpen ? <CheckCircle className="h-3 w-3 mr-1" /> : <XCircle className="h-3 w-3 mr-1" />}
                  {isOpen ? 'Open' : 'Closed'}
                </Badge>
              </div>

              {medDetails && store.medicines && store.medicines[medDetails.name] && (
                <div className="bg-purple-50 p-2.5 rounded-lg mb-3 text-sm border border-purple-100">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-purple-700 truncate pr-2">{medDetails.name}</span>
                    <span className="text-purple-600 font-bold whitespace-nowrap">
                      MRP: ₹{medDetails.price}
                    </span>
                  </div>
                  {medComposition && (
                    <p className="text-xs text-purple-500 mt-1 flex items-center">
                      <FlaskConical className="h-3 w-3 mr-1 text-purple-400" />
                      <span className="font-semibold mr-1">Composition:</span> {medComposition}
                    </p>
                  )}
                  <p className="text-xs text-purple-500 mt-1">
                     <span className="font-semibold">Use:</span> {medicineInfo[medDetails.name]?.description || "General purpose medicine."}
                  </p>
                  <p className="text-xs text-purple-500">
                    {medDetails.stock} in stock
                  </p>
                </div>
              )}
            </div>

            <div className="flex space-x-2 mt-auto pt-3 border-t border-slate-100">
               <Button 
                size="sm" 
                className="flex-1 text-xs bg-gradient-to-r from-sky-500 to-blue-500 hover:from-sky-600 hover:to-blue-600"
                onClick={(e) => handleDirectionsClick(e, store)}
              >
                <Navigation className="h-3.5 w-3.5 mr-1" />
                Directions
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                className="flex-1 text-xs border-purple-300 text-purple-600 hover:bg-purple-50 hover:border-purple-400"
                onClick={(e) => handleCallClick(e)}
              >
                <Phone className="h-3.5 w-3.5 mr-1" />
                Call
              </Button>
            </div>
          </Card>
        </motion.div>
        );
      })}
    </div>
  );
};

export default StoreList;