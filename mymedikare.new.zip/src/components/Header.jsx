import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { MapPin, ChevronDown } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.jsx";
import Auth from '@/components/Auth';

const Header = ({ logo, appName, cities, selectedCity, onCityChange, user, onLogin, onSignup, onLogout, onLogoClick }) => {
  const [isCityOpen, setIsCityOpen] = useState(false);

  return (
    <motion.header
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ type: 'spring', stiffness: 120, damping: 20 }}
      className="sticky top-0 z-50 bg-gradient-to-r from-purple-700 via-blue-600 to-sky-500 text-white shadow-lg dark:from-purple-800 dark:via-blue-700 dark:to-sky-600"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <a href="/" onClick={(e) => { e.preventDefault(); onLogoClick(); }} className="flex items-center cursor-pointer">
            <img src={logo} alt={`${appName} Logo`} className="h-10 w-10 md:h-12 md:w-12 mr-2 rounded-full object-cover" />
            <span className="font-bold text-xl md:text-2xl tracking-tight">{appName}</span>
          </a>

          <div className="flex items-center space-x-1 md:space-x-3">
            <DropdownMenu open={isCityOpen} onOpenChange={setIsCityOpen}>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="text-white hover:bg-white/10 focus:bg-white/10 px-2 md:px-3 py-2 rounded-md text-sm"
                >
                  <MapPin className="h-4 w-4 md:h-5 md:w-5 mr-1 md:mr-2" />
                  <span className="hidden sm:inline">{selectedCity.name}</span>
                  <span className="sm:hidden">
                    {selectedCity.name.length > 10 ? selectedCity.name.substring(0,7) + "..." : selectedCity.name}
                  </span>
                  <ChevronDown className={`h-4 w-4 ml-1 transition-transform duration-200 ${isCityOpen ? 'rotate-180' : ''}`} />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56 bg-white dark:bg-slate-800 shadow-xl rounded-lg mt-2 border-slate-200 dark:border-slate-700">
                {cities.map((city) => (
                  <DropdownMenuItem
                    key={city.name}
                    onSelect={() => onCityChange(city)}
                    className="text-slate-700 dark:text-slate-200 hover:bg-purple-50 dark:hover:bg-purple-700/30 !focus:bg-purple-100 dark:!focus:bg-purple-600/40 cursor-pointer px-3 py-2 text-sm"
                  >
                    {city.name}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <div className="border-l border-white/20 h-8 mx-2 hidden sm:block"></div>

            <Auth user={user} onLoginClick={onLogin} onSignupClick={onSignup} onLogout={onLogout} />
           
          </div>
        </div>
      </div>
    </motion.header>
  );
};

export default Header;