import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { X, FileText, Pill, ShieldCheck, Lightbulb, Info } from 'lucide-react';

const blogPosts = [
  {
    id: 1,
    title: "Understanding Paracetamol: More Than Just a Fever Reducer",
    category: "Medicine Explained",
    icon: Pill,
    summary: "Paracetamol is a common household medicine known for relieving pain and reducing fever. It works by blocking chemical messengers in the brain that tell us we have pain and by affecting the chemical messengers that control body temperature. It's generally safe when used as directed, but exceeding the recommended dose can lead to liver damage. Always check the strength and dosage instructions, especially for children.",
    content: `
      <p class="mb-3">Paracetamol, also known as acetaminophen, is one of the most widely used over-the-counter analgesics (pain relievers) and antipyretics (fever reducers). Its exact mechanism of action is not fully understood, but it's believed to primarily work in the central nervous system (brain and spinal cord).</p>
      <h3 class="text-lg font-semibold mt-4 mb-2 text-slate-700 dark:text-slate-200">How it Works:</h3>
      <ul class="list-disc list-inside space-y-1 mb-3 text-sm">
        <li><strong>Pain Relief:</strong> It's thought to inhibit the synthesis of prostaglandins in the brain. Prostaglandins are chemicals that are released in response to illness or injury and cause pain and inflammation.</li>
        <li><strong>Fever Reduction:</strong> Paracetamol acts on the heat-regulating center of the brain (the hypothalamus) to cool the body when a fever is present.</li>
      </ul>
      <h3 class="text-lg font-semibold mt-4 mb-2 text-slate-700 dark:text-slate-200">Key Uses:</h3>
      <ul class="list-disc list-inside space-y-1 mb-3 text-sm">
        <li>Headaches (tension headaches, migraines)</li>
        <li>Muscle aches and pains</li>
        <li>Arthritis (mild to moderate pain)</li>
        <li>Backache</li>
        <li>Toothaches</li>
        <li>Colds and flu (symptomatic relief of fever and aches)</li>
      </ul>
      <h3 class="text-lg font-semibold mt-4 mb-2 text-slate-700 dark:text-slate-200">Important Considerations:</h3>
      <ul class="list-disc list-inside space-y-1 text-sm">
        <li><strong>Dosage is Crucial:</strong> Always follow the recommended dosage on the packaging or as prescribed by your doctor. Overdosing can cause severe liver damage, which can be fatal.</li>
        <li><strong>Check Other Medications:</strong> Many combination cold and flu remedies also contain paracetamol. Be careful not to take multiple products containing paracetamol simultaneously to avoid exceeding the safe daily limit.</li>
        <li><strong>Alcohol:</strong> Avoid drinking excessive amounts of alcohol when taking paracetamol, as this can increase the risk of liver damage.</li>
        <li><strong>Children:</strong> Use specific children's formulations and dosages. Never give adult-strength paracetamol to children unless directed by a doctor.</li>
      </ul>
    `
  },
  {
    id: 2,
    title: "Demystifying Antibiotics: When and How to Use Them",
    category: "Safe Medicine Use",
    icon: ShieldCheck,
    summary: "Antibiotics are powerful medicines that fight bacterial infections. They don't work against viruses like those that cause colds or flu. It's crucial to use antibiotics only when prescribed by a doctor and to complete the full course, even if you start feeling better. Misusing antibiotics can lead to antibiotic resistance, making future infections harder to treat.",
    content: `
      <p class="mb-3">Antibiotics are a cornerstone of modern medicine, responsible for saving countless lives since their discovery. However, their effectiveness is under threat due to the rise of antibiotic resistance.</p>
      <h3 class="text-lg font-semibold mt-4 mb-2 text-slate-700 dark:text-slate-200">What They Do (and Don't Do):</h3>
      <ul class="list-disc list-inside space-y-1 mb-3 text-sm">
        <li><strong>Target Bacteria:</strong> Antibiotics work by killing bacteria or preventing them from reproducing. Different antibiotics target different types of bacteria.</li>
        <li><strong>Not for Viruses:</strong> They are ineffective against viral infections such as the common cold, flu, most sore throats, bronchitis, and many sinus and ear infections. Using antibiotics for viral infections won't help you get better faster and can contribute to antibiotic resistance.</li>
      </ul>
      <h3 class="text-lg font-semibold mt-4 mb-2 text-slate-700 dark:text-slate-200">Golden Rules of Antibiotic Use:</h3>
      <ul class="list-disc list-inside space-y-1 mb-3 text-sm">
        <li><strong>Only When Prescribed:</strong> Never take antibiotics unless they have been prescribed for you by a healthcare professional for a current infection.</li>
        <li><strong>Complete the Full Course:</strong> Always finish the entire course of antibiotics as prescribed, even if you start feeling better. Stopping early can allow remaining bacteria to multiply and develop resistance.</li>
        <li><strong>Don't Share Antibiotics:</strong> Never share your antibiotics with others, and don't use leftover prescriptions. The antibiotic might not be appropriate for their condition.</li>
        <li><strong>Follow Instructions:</strong> Take antibiotics exactly as directed (e.g., with or without food, at specific times).</li>
        <li><strong>Inform Your Doctor:</strong> Tell your doctor about any allergies or other medications you are taking.</li>
      </ul>
      <h3 class="text-lg font-semibold mt-4 mb-2 text-slate-700 dark:text-slate-200">The Threat of Antibiotic Resistance:</h3>
      <p class="text-sm">Antibiotic resistance occurs when bacteria change in response to the use of these medicines, making infections harder to treat. This is a serious global health threat. Responsible antibiotic use by everyone is crucial to preserve their effectiveness for future generations.</p>
    `
  },
  {
    id: 3,
    title: "5 Simple Tips for a Healthier Lifestyle in Odisha",
    category: "Health & Wellness",
    icon: Lightbulb,
    summary: "Living a healthy lifestyle involves making conscious choices every day. Here are five simple yet effective tips you can incorporate: Stay hydrated, especially in Odisha's climate; eat a balanced diet rich in local fruits and vegetables; get regular physical activity; ensure adequate sleep; and manage stress effectively.",
    content: `
      <p class="mb-3">Adopting a healthier lifestyle doesn't have to be complicated. Small, consistent changes can make a big difference to your overall well-being. Here are some tips tailored for Odisha:</p>
      <h3 class="text-lg font-semibold mt-4 mb-2 text-slate-700 dark:text-slate-200">1. Stay Hydrated (ପର୍ଯ୍ୟାପ୍ତ ପାଣି ପିଅନ୍ତୁ):</h3>
      <p class="text-sm mb-3">Odisha's climate can be hot and humid. Drink plenty of water throughout the day to stay hydrated. Coconut water (ପଇଡ଼ ପାଣି) is also a great natural hydrator. Aim for at least 8-10 glasses of water daily.</p>
      
      <h3 class="text-lg font-semibold mt-4 mb-2 text-slate-700 dark:text-slate-200">2. Balanced Diet with Local Produce (ସୁଷମ ଆହାର):</h3>
      <p class="text-sm mb-3">Incorporate plenty of fresh, local fruits and vegetables into your meals. Odisha offers a rich variety like mangoes, jackfruit, bananas, leafy greens (ଶାଗ), and various gourds. Focus on whole grains like rice and millets (ମାଣ୍ଡିଆ), lean proteins (fish, lentils), and healthy fats.</p>

      <h3 class="text-lg font-semibold mt-4 mb-2 text-slate-700 dark:text-slate-200">3. Regular Physical Activity (ନିୟମିତ ବ୍ୟାୟାମ):</h3>
      <p class="text-sm mb-3">Aim for at least 30 minutes of moderate-intensity exercise most days of the week. This could be brisk walking, cycling, swimming, or practicing yoga. Even simple activities like taking the stairs or walking for errands count.</p>

      <h3 class="text-lg font-semibold mt-4 mb-2 text-slate-700 dark:text-slate-200">4. Ensure Adequate Sleep (ପର୍ଯ୍ୟାପ୍ତ ନିଦ):</h3>
      <p class="text-sm mb-3">Most adults need 7-9 hours of quality sleep per night. Good sleep is essential for physical and mental health, helping with mood, concentration, and immune function. Establish a regular sleep schedule.</p>

      <h3 class="text-lg font-semibold mt-4 mb-2 text-slate-700 dark:text-slate-200">5. Manage Stress Effectively (ଚାପ ପରିଚାଳନା):</h3>
      <p class="text-sm">Find healthy ways to cope with stress. This could include meditation, spending time in nature, hobbies, listening to music, or talking to friends and family. Chronic stress can negatively impact your health.</p>
    `
  },
  {
    id: 4,
    title: "The Importance of Completing Your Medicine Course",
    category: "Safe Medicine Use",
    icon: ShieldCheck,
    summary: "Ever felt better and thought about stopping your medication early? It's a common temptation, but often a mistake, especially with antibiotics. Completing the full prescribed course ensures all harmful bacteria are eliminated, preventing recurrence and the development of drug-resistant strains. Always follow your doctor's advice.",
    content: `
      <p class="mb-3">When a doctor prescribes a course of medication, especially antibiotics, it's based on scientific evidence about how long it takes to effectively treat an infection. Stopping early, even if you feel better, can have negative consequences.</p>
      <h3 class="text-lg font-semibold mt-4 mb-2 text-slate-700 dark:text-slate-200">Why Finishing the Course Matters:</h3>
      <ul class="list-disc list-inside space-y-1 mb-3 text-sm">
        <li><strong>Eliminating All Bacteria:</strong> Feeling better doesn't always mean all the harmful bacteria are gone. Some may still be present in smaller numbers. Stopping medication prematurely allows these survivors to multiply, potentially causing the infection to return.</li>
        <li><strong>Preventing Relapse:</strong> A relapsed infection can sometimes be more severe and harder to treat than the initial one.</li>
        <li><strong>Combating Antibiotic Resistance:</strong> This is particularly crucial for antibiotics. When bacteria are exposed to an antibiotic but not completely killed off, the surviving bacteria can develop resistance to that antibiotic. These resistant strains are much harder to treat and can spread to others.</li>
        <li><strong>Ensuring Full Treatment Efficacy:</strong> For many conditions, the full duration of treatment is necessary to achieve the desired therapeutic effect and prevent long-term complications.</li>
      </ul>
      <h3 class="text-lg font-semibold mt-4 mb-2 text-slate-700 dark:text-slate-200">What to Do:</h3>
      <ul class="list-disc list-inside space-y-1 text-sm">
        <li><strong>Follow Doctor's Orders:</strong> Always take your medication for the full duration prescribed by your doctor or healthcare provider.</li>
        <li><strong>Don't 'Save' Medication:</strong> Never keep leftover medication for future use. It might not be appropriate for a different illness, or it could be expired.</li>
        <li><strong>Discuss Concerns:</strong> If you experience side effects or have concerns about your medication, talk to your doctor before stopping. They may be able to adjust the dose or suggest an alternative.</li>
      </ul>
      <p class="mt-3 text-sm">Completing your prescribed medication course is a simple yet vital step in ensuring your recovery and protecting public health by preventing the spread of drug-resistant infections.</p>
    `
  },
  {
    id: 5,
    title: "Decoding Medicine Labels: Key Information to Look For",
    category: "Medicine Information",
    icon: Info,
    summary: "Medicine labels contain vital information. Understanding them helps you use medications safely and effectively. Key things to check include active ingredients, dosage, warnings, expiration date, and storage instructions. Always read the label before taking any medicine.",
    content: `
      <p class="mb-3">The label on your medicine package or bottle is a crucial source of information. Taking a few moments to understand it can significantly improve your safety and the medicine's effectiveness.</p>
      <h3 class="text-lg font-semibold mt-4 mb-2 text-slate-700 dark:text-slate-200">Key Sections on a Medicine Label:</h3>
      <ul class="list-disc list-inside space-y-1 mb-3 text-sm">
        <li><strong>Active Ingredient(s):</strong> This is the therapeutic substance in the medicine that treats your condition. Knowing this helps avoid taking too much of the same ingredient if you're using multiple products (e.g., Paracetamol in different cold remedies). It also tells you the strength (e.g., 500mg).</li>
        <li><strong>Uses:</strong> This section describes the symptoms or conditions the medicine is approved to treat.</li>
        <li><strong>Warnings:</strong> This is a very important section. It includes information about when you shouldn't use the medicine, conditions that might require special caution (e.g., pregnancy, liver disease), potential side effects, and drug interactions.</li>
        <li><strong>Directions/Dosage:</strong> This tells you how much medicine to take, how often, and for how long. It's critical to follow these instructions precisely. Pay attention to age-specific or weight-specific dosing if applicable.</li>
        <li><strong>Other Information:</strong> This may include storage instructions (e.g., "store in a cool, dry place," "refrigerate after opening") and the manufacturer's details.</li>
        <li><strong>Inactive Ingredients:</strong> These are substances used to form the tablet, capsule, or liquid, such as fillers, binders, colors, and preservatives. Important if you have allergies to specific inactive ingredients.</li>
        <li><strong>Expiration Date (EXP):</strong> Do not use medicine after this date, as it may be less effective or potentially harmful.</li>
        <li><strong>Lot/Batch Number:</strong> Useful for manufacturers to track products in case of a recall.</li>
      </ul>
      <h3 class="text-lg font-semibold mt-4 mb-2 text-slate-700 dark:text-slate-200">Tips for Reading Labels:</h3>
      <ul class="list-disc list-inside space-y-1 text-sm">
        <li>Always read the label before each dose, even if you've taken the medicine before, as formulations can change.</li>
        <li>Use good lighting and your reading glasses if needed.</li>
        <li>If you don't understand something, ask your pharmacist or doctor. Never guess.</li>
        <li>Keep medicines in their original containers so the label is always available.</li>
      </ul>
      <p class="mt-3 text-sm">Being an informed patient starts with understanding your medications. Reading and understanding labels is a key part of safe and effective medicine use.</p>
    `
  },
  {
    id: 6,
    title: "Managing Common Side Effects of Medications",
    category: "Safe Medicine Use",
    icon: ShieldCheck,
    summary: "Most medicines can cause side effects, though not everyone gets them. Common ones include nausea, drowsiness, or headache. Knowing what to expect and how to manage minor side effects can make your treatment more comfortable. Always report severe or persistent side effects to your doctor.",
    content: `
      <p class="mb-3">While medicines are designed to help us, they can sometimes cause unwanted effects, known as side effects. Most are mild and temporary, but it's good to be aware.</p>
      <h3 class="text-lg font-semibold mt-4 mb-2 text-slate-700 dark:text-slate-200">Common Mild Side Effects and Management:</h3>
      <ul class="list-disc list-inside space-y-2 mb-3 text-sm">
        <li><strong>Nausea/Upset Stomach:</strong>
            <ul class="list-circle list-inside ml-4 text-xs">
                <li>Take the medicine with food or milk (if allowed - check the label or ask your pharmacist).</li>
                <li>Eat small, frequent meals rather than large ones.</li>
                <li>Avoid spicy, fatty, or very sweet foods.</li>
                <li>Sip ginger ale or peppermint tea.</li>
            </ul>
        </li>
        <li><strong>Drowsiness/Dizziness:</strong>
            <ul class="list-circle list-inside ml-4 text-xs">
                <li>Avoid driving or operating heavy machinery until you know how the medicine affects you.</li>
                <li>Take the medicine at bedtime if it causes significant drowsiness (if appropriate for the dosing schedule).</li>
                <li>Stand up slowly from a sitting or lying position.</li>
            </ul>
        </li>
        <li><strong>Headache:</strong>
            <ul class="list-circle list-inside ml-4 text-xs">
                <li>Rest in a quiet, dark room.</li>
                <li>Apply a cool compress to your forehead.</li>
                <li>Ensure you are well-hydrated.</li>
                <li>A mild pain reliever like paracetamol might help (check for interactions first).</li>
            </ul>
        </li>
        <li><strong>Dry Mouth:</strong>
            <ul class="list-circle list-inside ml-4 text-xs">
                <li>Sip water frequently.</li>
                <li>Suck on sugar-free candy or chew sugar-free gum.</li>
                <li>Avoid caffeine and alcohol, which can worsen dry mouth.</li>
            </ul>
        </li>
        <li><strong>Constipation:</strong>
            <ul class="list-circle list-inside ml-4 text-xs">
                <li>Increase your intake of fiber-rich foods (fruits, vegetables, whole grains).</li>
                <li>Drink plenty of water.</li>
                <li>Engage in regular physical activity.</li>
            </ul>
        </li>
      </ul>
      <h3 class="text-lg font-semibold mt-4 mb-2 text-slate-700 dark:text-slate-200">When to Contact Your Doctor:</h3>
      <ul class="list-disc list-inside space-y-1 text-sm">
        <li>If side effects are severe or very bothersome.</li>
        <li>If you experience signs of an allergic reaction (rash, hives, itching, swelling of the face/tongue/throat, difficulty breathing). This is an emergency.</li>
        <li>If side effects don't go away after a few days or get worse.</li>
        <li>If you develop any new or unexpected symptoms.</li>
      </ul>
      <p class="mt-3 text-sm">Don't stop taking a prescribed medicine without talking to your doctor first, even if you have side effects. They may be able to adjust the dose, switch you to a different medication, or offer other ways to manage the side effects.</p>
    `
  }
];


const HealthBlogModal = ({ isOpen, onOpenChange }) => {
  const [selectedPost, setSelectedPost] = useState(null);

  if (!isOpen) return null;

  const handlePostSelect = (post) => {
    setSelectedPost(post);
  };

  const handleBackToList = () => {
    setSelectedPost(null);
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => { if(!open) setSelectedPost(null); onOpenChange(open);}}>
      <DialogContent 
        className="w-full max-w-3xl p-0 border-0 bg-slate-50 dark:bg-slate-900 rounded-xl shadow-2xl"
        onInteractOutside={(e) => { if(!selectedPost) onOpenChange(false);}}
      >
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="max-h-[85vh] flex flex-col"
        >
          <DialogHeader className="p-6 sticky top-0 bg-slate-100 dark:bg-slate-800 rounded-t-xl border-b border-slate-200 dark:border-slate-700 z-10">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <FileText className="h-7 w-7 text-purple-600 dark:text-purple-400 mr-3"/>
                <div>
                  <DialogTitle className="text-2xl font-bold text-slate-800 dark:text-slate-100">
                    {selectedPost ? selectedPost.title : "Health Blog & Wellness Tips"}
                  </DialogTitle>
                  <DialogDescription className="text-sm text-slate-500 dark:text-slate-400">
                    {selectedPost ? selectedPost.category : "Insights on medicines, health, and well-being."}
                  </DialogDescription>
                </div>
              </div>
              <Button variant="ghost" size="icon" onClick={() => {setSelectedPost(null); onOpenChange(false);}} className="rounded-full text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200">
                <X className="h-5 w-5" />
              </Button>
            </div>
            {selectedPost && (
              <Button variant="outline" size="sm" onClick={handleBackToList} className="mt-3 text-purple-600 border-purple-300 hover:bg-purple-50 dark:text-purple-400 dark:border-purple-600 dark:hover:bg-purple-700/30">
                &larr; Back to Blog List
              </Button>
            )}
          </DialogHeader>
          
          <div className="p-6 overflow-y-auto flex-grow">
            <AnimatePresence mode="wait">
              {selectedPost ? (
                <motion.div
                  key={selectedPost.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="prose prose-sm sm:prose-base max-w-none dark:prose-invert prose-headings:text-slate-700 dark:prose-headings:text-slate-200 prose-p:text-slate-600 dark:prose-p:text-slate-300 prose-li:text-slate-600 dark:prose-li:text-slate-300"
                  dangerouslySetInnerHTML={{ __html: selectedPost.content }}
                />
              ) : (
                <motion.div 
                  key="list"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="grid grid-cols-1 md:grid-cols-2 gap-6"
                >
                  {blogPosts.map((post) => {
                    const Icon = post.icon;
                    return (
                    <motion.div
                      key={post.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: post.id * 0.1 }}
                      className="bg-white dark:bg-slate-800 p-5 rounded-lg shadow-lg hover:shadow-xl transition-shadow cursor-pointer border border-slate-200 dark:border-slate-700"
                      onClick={() => handlePostSelect(post)}
                    >
                      <div className="flex items-start mb-3">
                        <div className="p-2 bg-purple-100 dark:bg-purple-700/30 rounded-full mr-3">
                          <Icon className="h-6 w-6 text-purple-600 dark:text-purple-400"/>
                        </div>
                        <div>
                           <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100 mb-1">{post.title}</h3>
                           <p className="text-xs text-purple-500 dark:text-purple-400 font-medium">{post.category}</p>
                        </div>
                      </div>
                      <p className="text-sm text-slate-600 dark:text-slate-300 line-clamp-3 mb-3">{post.summary}</p>
                      <Button variant="link" className="p-0 text-sm text-purple-600 dark:text-purple-400 hover:underline">Read More &rarr;</Button>
                    </motion.div>
                  )}
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </DialogContent>
    </Dialog>
  );
};

export default HealthBlogModal;