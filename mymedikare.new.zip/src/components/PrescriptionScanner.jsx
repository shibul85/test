import React, { useState, useRef, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Camera, Upload, X, FileText, Zap, BrainCircuit } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { DialogContent } from '@/components/ui/dialog';
import GoogleLensIcon from '@/components/icons/GoogleLensIcon';

function PrescriptionScanner({ onScanComplete, onClose }) {
  const [isScanning, setIsScanning] = useState(false);
  const [scannedText, setScannedText] = useState('');
  const [selectedImage, setSelectedImage] = useState(null);
  const fileInputRef = useRef(null);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  const performOCR = useCallback(async (imageData) => {
    setIsScanning(true);
    setScannedText('');
    
    toast({
      title: "Connecting to AI Scanner...",
      description: "Simulating a connection to Google Lens API. This requires backend integration and API keys."
    });
    
    await new Promise(resolve => setTimeout(resolve, 2500));
    
    const mockMedicines = [
      'Telma 40', 'Paracetamol 650mg', 'Atorvastatin 20mg',
      'Rosuvas 10', 'Amlong 5mg', 'Metformin 500mg', 'Glimestar M2',
      'Pantocid DSR', 'Azithral 500', 'Montair LC'
    ];
    
    const detectedCount = Math.floor(Math.random() * 3) + 1;
    let detectedMedicines = new Set();
    while (detectedMedicines.size < detectedCount) {
      detectedMedicines.add(mockMedicines[Math.floor(Math.random() * mockMedicines.length)]);
    }

    const resultText = Array.from(detectedMedicines).join(', ');
    setScannedText(resultText);
    setIsScanning(false);
    
    toast({
      title: "AI Scan Complete!",
      description: `Detected: ${resultText}`
    });
  }, []);

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setSelectedImage(e.target.result);
        performOCR(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setSelectedImage(null);
      }
    } catch (error) {
      toast({
        title: "Camera Access Denied",
        description: "Please allow camera access in your browser settings.",
        variant: "destructive"
      });
      onClose();
    }
  };

  const stopCamera = useCallback(() => {
    if (videoRef.current && videoRef.current.srcObject) {
      videoRef.current.srcObject.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
  }, []);

  const captureImage = () => {
    if (videoRef.current?.srcObject) {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas.getContext('2d').drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
      const imageData = canvas.toDataURL('image/jpeg');
      setSelectedImage(imageData);
      performOCR(imageData);
      stopCamera();
    }
  };

  const handleConfirm = () => {
    if (scannedText) {
      onScanComplete(scannedText.split(',')[0].trim());
    }
  };
  
  const handleClose = useCallback(() => {
    stopCamera();
    onClose();
  }, [onClose, stopCamera]);

  useEffect(() => () => stopCamera(), [stopCamera]);

  const resetScanner = () => {
    setSelectedImage(null);
    setScannedText('');
    stopCamera();
  };

  const renderInitialScreen = () => (
    <motion.div key="uploadOptions" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <Button onClick={() => fileInputRef.current?.click()} className="h-32 flex-col space-y-2 bg-gradient-to-br from-purple-500 to-blue-600 hover:from-purple-600 hover:to-blue-700 text-white">
          <Upload className="h-8 w-8" /><span>Upload Image</span>
        </Button>
        <Button onClick={startCamera} variant="outline" className="h-32 flex-col space-y-2 border-2 border-purple-200 hover:border-purple-400 text-purple-600 hover:text-purple-700 dark:border-purple-700 dark:text-purple-300 dark:hover:border-purple-500 dark:hover:text-purple-200">
          <Camera className="h-8 w-8" /><span>Use Camera</span>
        </Button>
      </div>
      <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
      <div className="text-center text-sm text-slate-500 dark:text-slate-400 pt-4"><FileText className="h-10 w-10 mx-auto mb-2 text-slate-400 dark:text-slate-500" /><p>Upload a clear photo of your prescription or use your camera to scan it directly.</p></div>
    </motion.div>
  );

  const renderCameraView = () => (
    <motion.div key="cameraView" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }} className="relative">
      <video ref={videoRef} autoPlay playsInline className="w-full rounded-lg aspect-[4/3] object-cover bg-slate-900" />
      <div className="absolute inset-0 border-4 border-purple-400 dark:border-purple-600 rounded-lg flex items-center justify-center pointer-events-none">
        <div className="w-4/5 h-3/4 border-2 border-white/70 rounded-lg relative animate-pulse" />
      </div>
      <Button onClick={captureImage} className="absolute bottom-6 left-1/2 transform -translate-x-1/2 bg-white text-purple-600 hover:bg-slate-100 dark:bg-slate-800 dark:text-purple-300 dark:hover:bg-slate-700 shadow-lg py-3 px-6 text-base"><Camera className="h-5 w-5 mr-2" />Capture</Button>
    </motion.div>
  );

  const renderResultView = () => (
    <motion.div key="resultView" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-5">
      <img src={selectedImage} alt="Prescription" className="w-full max-h-64 object-contain rounded-lg bg-slate-100 dark:bg-slate-800 p-1" />
      {isScanning ? (
        <div className="text-center py-6">
          <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="p-4 bg-white dark:bg-slate-700 rounded-full shadow-xl inline-block">
            <Zap className="h-8 w-8 text-purple-600 dark:text-purple-400" />
          </motion.div>
          <motion.p animate={{ opacity: [1, 0.6, 1] }} transition={{ duration: 1.2, repeat: Infinity }} className="text-purple-600 dark:text-purple-400 font-medium mt-3 text-lg">AI is analyzing...</motion.p>
        </div>
      ) : scannedText ? (
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="bg-green-50 dark:bg-green-800/30 border border-green-200 dark:border-green-700 rounded-lg p-5">
          <div className="flex items-center space-x-2 mb-2.5"><div className="w-3 h-3 bg-green-500 dark:bg-green-400 rounded-full pulse-animation" /><span className="text-md font-semibold text-green-800 dark:text-green-200">Medicines Detected</span></div>
          <p className="text-xl font-bold text-green-900 dark:text-green-100">{scannedText}</p>
        </motion.div>
      ) : (
        <div className="bg-red-50 dark:bg-red-800/30 border border-red-200 dark:border-red-700 rounded-lg p-5"><p className="text-red-800 dark:text-red-200 font-medium text-md">No medicine detected. Please try a clearer image or adjust lighting.</p></div>
      )}
      <div className="flex space-x-4 pt-3">
        <Button onClick={resetScanner} variant="outline" className="flex-1 py-3 text-base border-purple-300 text-purple-600 hover:bg-purple-50 dark:border-purple-600 dark:text-purple-300 dark:hover:bg-purple-700/30">Try Again</Button>
        {scannedText && !isScanning && <Button onClick={handleConfirm} className="flex-1 py-3 text-base bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white">Search Medicines</Button>}
      </div>
    </motion.div>
  );

  return (
    <DialogContent className="w-full max-w-lg p-0 border-0 bg-transparent shadow-none" onInteractOutside={handleClose}>
      <Card className="shadow-2xl bg-slate-50 dark:bg-slate-900">
        <CardHeader className="p-6 border-b dark:border-slate-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-purple-100 dark:bg-purple-800/40 rounded-full"><BrainCircuit className="h-7 w-7 text-purple-600 dark:text-purple-400" /></div>
              <div>
                <CardTitle className="text-2xl text-slate-800 dark:text-slate-100">AI Prescription Scanner</CardTitle>
                <div className="flex items-center text-xs text-slate-500 dark:text-slate-400">Powered by <GoogleLensIcon className="h-3.5 w-3.5 mx-1" /> Google Lens Tech (Simulated)</div>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={handleClose} className="rounded-full text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"><X className="h-5 w-5" /></Button>
          </div>
        </CardHeader>
        <CardContent className="p-6 md:p-8">
          <AnimatePresence mode="wait">
            {!selectedImage && !videoRef.current?.srcObject ? renderInitialScreen() : videoRef.current?.srcObject && !selectedImage ? renderCameraView() : renderResultView()}
          </AnimatePresence>
          <canvas ref={canvasRef} className="hidden" />
        </CardContent>
      </Card>
    </DialogContent>
  );
}

export default PrescriptionScanner;