import React from 'react';
import { motion } from 'framer-motion';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { X, Award, Briefcase } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const AboutUsModal = ({ isOpen, onOpenChange }) => {
  const founderImage = "https://storage.googleapis.com/hostinger-horizons-assets-prod/9e7c0e90-d1ac-4b7d-957f-05928bb6595e/08a8dc67df699a0d42a31ba84998ecb9.jpg";

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent 
        className="w-full max-w-md p-0 border-0 rounded-xl overflow-hidden" 
        onInteractOutside={() => onOpenChange(false)}
      >
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          transition={{ duration: 0.3 }}
        >
          <div className="relative">
            <div className="h-28 bg-gradient-to-r from-purple-600 via-blue-500 to-sky-400"></div>
            <div className="absolute top-16 left-1/2 -translate-x-1/2">
               <Avatar className="h-24 w-24 border-4 border-white shadow-lg">
                <AvatarImage src={founderImage} alt="Shibul Kumar Padhan" />
                <AvatarFallback>SKP</AvatarFallback>
              </Avatar>
            </div>
            <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)} className="absolute top-3 right-3 text-white hover:bg-white/20 rounded-full h-8 w-8">
              <X className="h-5 w-5" />
            </Button>
          </div>
          
          <div className="pt-16 p-6 text-center">
            <h2 className="text-2xl font-bold text-slate-800">Shibul Kumar Padhan</h2>
            <p className="text-base text-purple-600 font-medium">CEO & Founder</p>
            
            <p className="text-sm text-slate-600 mt-4 leading-relaxed">
              Shibul is the visionary behind MyMedikare, driven by a passion to make healthcare accessible for everyone in Odisha. His dedication and innovative spirit are at the heart of our mission.
            </p>
            
            <div className="flex justify-center gap-6 mt-6 text-sm text-slate-500">
               <div className="flex items-center">
                 <Award className="h-4 w-4 mr-1.5 text-amber-500"/>
                 <span>Innovator</span>
               </div>
               <div className="flex items-center">
                 <Briefcase className="h-4 w-4 mr-1.5 text-sky-500"/>
                 <span>Entrepreneur</span>
               </div>
            </div>
          </div>
          
          <div className="p-4 bg-slate-50 text-center">
             <p className="text-xs text-slate-500">&copy; {new Date().getFullYear()} MyMedikare</p>
          </div>
        </motion.div>
      </DialogContent>
    </Dialog>
  );
};

export default AboutUsModal;