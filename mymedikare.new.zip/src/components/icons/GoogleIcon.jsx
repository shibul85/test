import React from 'react';

const GoogleIcon = (props) => (
  <svg
    viewBox="0 0 24 24"
    fill="currentColor"
    height="1em"
    width="1em"
    {...props}
  >
    <path
      fillRule="evenodd"
      d="M12.24 10.285V14.4h6.806c-.275 1.765-2.056 5.174-6.806 5.174-4.095 0-7.439-3.386-7.439-7.574s3.344-7.574 7.439-7.574c2.33 0 3.891.989 4.785 1.85l3.25-3.138C18.189 1.186 15.479 0 12.24 0 5.49 0 0 5.49 0 12s5.49 12 12.24 12c6.957 0 11.533-4.872 11.533-11.755 0-.788-.085-1.39-.193-1.96h-11.34z"
    />
  </svg>
);

export default GoogleIcon;