import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Navigation, Phone, X, Star, Clock, MapPin, CheckCircle, XCircle, FlaskConical } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/components/ui/use-toast';
import { medicineInfo } from '@/data/medicineInfo';

const StoreDetailsModal = ({ store, onOpenChange, userLocation }) => {
  const [showAllMedicines, setShowAllMedicines] = useState(false);
  if (!store) return null;

  const dummyIndianPhoneNumber = "+918144349805"; 

  const handleGetDirections = () => {
    if (userLocation && store.coordinates) {
      const { lat: userLat, lng: userLng } = userLocation;
      const [storeLat, storeLng] = store.coordinates;
      const googleMapsUrl = `https://www.google.com/maps/dir/?api=1&origin=${userLat},${userLng}&destination=${storeLat},${storeLng}&travelmode=driving`;
      window.open(googleMapsUrl, '_blank');
    } else {
      toast({
        title: "Cannot get directions",
        description: "User location or store location is missing.",
        variant: "destructive"
      });
    }
  };

  const handleCallStore = () => {
    window.location.href = `tel:${dummyIndianPhoneNumber}`;
    toast({
        title: "Calling Store",
        description: `Dialing ${dummyIndianPhoneNumber} (dummy number). This feature isn't fully implemented yet—but don't worry! You can request live call integration in your next prompt! 🚀`
    });
  };

  const isStoreOpenNow = () => {
    if (!store.openHours || store.openHours.toLowerCase() === "24/7") return true;
    try {
      const [openTimeStr, closeTimeStr] = store.openHours.split(' - ');
      const now = new Date();
      const currentHour = now.getHours();
      const currentMinute = now.getMinutes();

      const parseTime = (timeStr) => {
        const [time, modifier] = timeStr.split(' ');
        let [hours, minutes] = time.split(':').map(Number);
        if (modifier === 'PM' && hours < 12) hours += 12;
        if (modifier === 'AM' && hours === 12) hours = 0; 
        return { hours, minutes };
      };

      const open = parseTime(openTimeStr);
      const close = parseTime(closeTimeStr);
      
      const currentTimeInMinutes = currentHour * 60 + currentMinute;
      const openTimeInMinutes = open.hours * 60 + open.minutes;
      let closeTimeInMinutes = close.hours * 60 + close.minutes;

      if (closeTimeInMinutes < openTimeInMinutes) { 
        closeTimeInMinutes += 24 * 60; 
        if (currentTimeInMinutes < openTimeInMinutes) { 
          return (currentTimeInMinutes + 24*60) < closeTimeInMinutes && (currentTimeInMinutes + 24*60) >= (openTimeInMinutes);
        }
      }
      
      return currentTimeInMinutes >= openTimeInMinutes && currentTimeInMinutes < closeTimeInMinutes;
    } catch (error) {
      console.error("Error parsing store hours:", error);
      return false; 
    }
  };

  const storeOpen = isStoreOpenNow();
  const medicinesToShow = showAllMedicines ? Object.entries(store.medicines) : Object.entries(store.medicines).slice(0, 7);

  return (
    <Dialog open={!!store} onOpenChange={onOpenChange}>
      <DialogContent 
        className="w-full max-w-lg p-0 border-0 rounded-xl overflow-hidden" 
        onInteractOutside={() => onOpenChange(false)}
      >
        <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.3 }}
        >
        <Card className="shadow-2xl border-0">
          <CardHeader className="p-5 md:p-6 bg-gradient-to-br from-purple-600 via-blue-500 to-sky-400 text-white">
            <div className="flex justify-between items-start">
              <CardTitle className="text-xl md:text-2xl font-bold">{store.name}</CardTitle>
              <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)} className="text-white hover:bg-white/20 rounded-full h-8 w-8">
                <X className="h-5 w-5" />
              </Button>
            </div>
            <p className="text-sm text-purple-100 mt-1">{store.address}</p>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 pt-2 text-xs md:text-sm">
              <Badge variant="secondary" className="bg-white/15 text-white backdrop-blur-sm">
                <MapPin className="h-3 w-3 md:h-3.5 md:w-3.5 mr-1" />
                {store.distance} km
              </Badge>
              <div className="flex items-center">
                <Star className="h-3.5 w-3.5 md:h-4 md:w-4 text-yellow-300 fill-current mr-1" />
                <span>{store.rating}</span>
              </div>
               <Badge variant={storeOpen ? "default" : "destructive"} className={`text-white ${storeOpen ? 'bg-green-500/80' : 'bg-red-500/80'} backdrop-blur-sm`}>
                {storeOpen ? <CheckCircle className="h-3 w-3 md:h-3.5 md:w-3.5 mr-1" /> : <XCircle className="h-3 w-3 md:h-3.5 md:w-3.5 mr-1" />}
                {storeOpen ? 'Open' : 'Closed'}
              </Badge>
              <div className="flex items-center">
                <Clock className="h-3.5 w-3.5 md:h-4 md:w-4 mr-1" />
                <span>{store.openHours}</span>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-5 md:p-6 max-h-[50vh] overflow-y-auto">
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold mb-2 text-slate-800">Available Medicines</h3>
                <div className="space-y-1.5">
                  {medicinesToShow.map(([medicine, details], index) => ( 
                    <motion.div 
                      key={medicine} 
                      className="flex justify-between items-start py-2.5 border-b border-slate-100 last:border-b-0"
                      initial={{ opacity: 0, x: -15 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                    >
                      <div className="flex-1 pr-2">
                        <p className="font-medium text-slate-700 text-sm">{medicine}</p>
                        {medicineInfo[medicine]?.composition && (
                           <p className="text-xs text-slate-500 flex items-center">
                            <FlaskConical className="h-3 w-3 mr-1 text-purple-500" />
                            <span className="font-semibold mr-1">Composition:</span> {medicineInfo[medicine].composition}
                          </p>
                        )}
                        <p className="text-xs text-slate-500">
                          <span className="font-semibold">Use:</span> {medicineInfo[medicine]?.description || "General purpose medicine."}
                        </p>
                        <p className="text-xs text-slate-500">{details.stock} in stock</p>
                      </div>
                      <span className="font-bold text-purple-600 text-sm whitespace-nowrap">MRP: ₹{details.price}</span>
                    </motion.div>
                  ))}
                  {Object.keys(store.medicines).length > 7 && !showAllMedicines && (
                    <Button variant="link" className="text-purple-600 p-0 h-auto mt-2 text-sm" onClick={() => setShowAllMedicines(true)}>
                      Show {Object.keys(store.medicines).length - 7} more medicines...
                    </Button>
                  )}
                   {showAllMedicines && (
                    <Button variant="link" className="text-purple-600 p-0 h-auto mt-2 text-sm" onClick={() => setShowAllMedicines(false)}>
                      Show less
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="p-5 md:p-6 bg-slate-50 border-t border-slate-200">
            <div className="flex space-x-3 w-full">
                <Button onClick={handleGetDirections} className="flex-1 bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 text-sm">
                  <Navigation className="h-4 w-4 mr-2" />
                  Get Directions
                </Button>
                <Button onClick={handleCallStore} variant="outline" className="flex-1 border-purple-300 text-purple-600 hover:bg-purple-50 hover:border-purple-400 text-sm">
                  <Phone className="h-4 w-4 mr-2" />
                  Call Store
                </Button>
              </div>
          </CardFooter>
        </Card>
        </motion.div>
      </DialogContent>
    </Dialog>
  );
};

export default StoreDetailsModal;