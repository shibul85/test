import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { MapPin, Info } from 'lucide-react';

const LocationPopup = ({ isOpen, onClose, cityName }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <Dialog open={isOpen} onOpenChange={onClose}>
          <DialogContent className="sm:max-w-md bg-gradient-to-br from-purple-50 via-sky-50 to-indigo-50 rounded-xl shadow-2xl border-purple-200">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ type: "spring", stiffness: 300, damping: 25 }}
            >
              <DialogHeader className="mb-4 text-center">
                <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-purple-100 mb-3">
                  <MapPin className="h-8 w-8 text-purple-600" />
                </div>
                <DialogTitle className="text-2xl font-bold text-purple-700">Welcome to {cityName}!</DialogTitle>
                <DialogDescription className="text-slate-600 mt-2 text-sm">
                  You've selected {cityName}. We're excited to help you find pharmacies in this area.
                </DialogDescription>
              </DialogHeader>
              
              <div className="bg-purple-50 border border-purple-200 p-4 rounded-lg mb-6 text-sm">
                <div className="flex items-start">
                  <Info className="h-5 w-5 text-purple-500 mr-2.5 mt-0.5 flex-shrink-0" />
                  <p className="text-purple-700">
                    Did you know? {cityName} has a rich history and many well-stocked pharmacies to serve your needs. Our app will show you the best options available.
                  </p>
                </div>
              </div>

              <DialogFooter className="sm:justify-center">
                <Button 
                  onClick={onClose} 
                  className="w-full sm:w-auto bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 text-white font-semibold"
                >
                  Explore Pharmacies
                </Button>
              </DialogFooter>
            </motion.div>
          </DialogContent>
        </Dialog>
      )}
    </AnimatePresence>
  );
};

export default LocationPopup;